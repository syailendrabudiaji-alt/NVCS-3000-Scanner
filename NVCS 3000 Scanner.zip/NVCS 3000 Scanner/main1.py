import os
import csv
import math
import random
import time
from datetime import datetime

import cv2
import numpy as np
import pygame

try:
    from ultralytics import YOLO
except Exception:
    YOLO = None

# ============================================================
# NVCS 3000 Scanner
# Keys: F = power, E = scrollable module/info menu, ESC = close menu / exit
# Zoom: + or = to zoom in, - to zoom out, 0 to reset
# Space Module: R = movement + LIDAR scan, Q = night vision + distance
# ============================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(BASE_DIR, "assets")
IMAGE_DIR = os.path.join(ASSET_DIR, "Image")
AUDIO_DIR = os.path.join(ASSET_DIR, "audio")
MODEL_PATH = os.path.join(ASSET_DIR, "model", "yolov8n.pt")
LOG_DIR = os.path.join(BASE_DIR, "logs")
LOG_PATH = os.path.join(LOG_DIR, "scanner_events.csv")

SCREEN_W, SCREEN_H = 1000, 600
CAM_W, CAM_H = 800, 360
CAM_X, CAM_Y = 100, 100
FPS_LIMIT = 60
BATTERY_BASE_DRAIN_PER_SECOND = 0.07  # Scanner hardware baseline drain
BATTERY_CHARGE_PER_SECOND = 0.30  # About 5.5 minutes to recharge fully

# Additional battery use per enabled module, in percentage points per second.
# Heavier processing modules cost more; Threat Detector is especially expensive.
MODULE_ENERGY_COST = {
    "Nightvision": 0.035,
    "Human Detector": 0.090,
    "Threat Detector": 0.200,
    "Thermal Vision": 0.065,
    "Motion Tracker": 0.055,
    "Digital Zoom": 0.020,
    "Radar Scanner": 0.025,
    "Edge Detection": 0.050,
    "Event Recorder": 0.015,
    "Target Lock": 0.045,
    "Range Finder": 0.025,
    "Signal Scanner": 0.020,
    "Snapshot / Freeze Frame": 0.010,
    "Image Stabilizer": 0.085,
    "System Diagnostics": 0.010,
    "Echo Scan": 0.035,
    "Ghost Trail": 0.040,
    "Power Saver": -0.050,
    "LIDAR Scan": 0.075,
    "Object Classification": 0.135,
    "Motion Vector": 0.045,
    "Coordinate Grid": 0.008,
    "Light Analyzer": 0.025,
    "Proximity Alert": 0.035,
    "Interference Detector": 0.035,
    "Session Timeline": 0.012,
    "Split View": 0.025,
    "Detail Enhancer": 0.045,
    "Overload Protection": 0.008,
    "Track History": 0.030,
    "Minimal HUD": 0.005,
    "LIDAR 2.0 — Point Cloud": 0.095,
    "Surface Reconstruction": 0.080,
    "Multi-Pass Scan": 0.070,
    "Pixel Inspector": 0.008,
    "Pixel Counter": 0.020,
    "Object Ruler": 0.008,
    "Resolution Destroyer": 0.012,
    "Binary Vision": 0.035,
    "Brightness Seismograph": 0.012,
    "Quantum Scanner": 0.050,
    "Ransom Module": 0.065,
    "Error Module": 0.045,
    "Space Module": 0.040,
    "Anomaly Module": 0.035,
    "Power Module": 0.015,
}

# Use a smaller audio buffer to reduce playback latency so the Ransom sound
# starts on the same update that the A-90 idle face appears.
try:
    pygame.mixer.pre_init(frequency=44100, size=-16, channels=2, buffer=256)
except pygame.error:
    pass

pygame.init()
try:
    if not pygame.mixer.get_init():
        pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=256)
except pygame.error as exc:
    print(f"[NVCS] Audio unavailable: {exc}")

# More mixer channels, with channels 0-1 reserved so ordinary Sound.play()
# calls never grab the dedicated Ransom channel (Channel 1).
try:
    pygame.mixer.set_num_channels(16)
    pygame.mixer.set_reserved(2)
except pygame.error:
    pass

screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
pygame.display.set_caption("NVCS 3000 Scanner")
clock = pygame.time.Clock()
FONT = pygame.font.SysFont("consolas", 18)
SMALL = pygame.font.SysFont("consolas", 14)
TITLE = pygame.font.SysFont("consolas", 26, bold=True)

WHITE = (240, 245, 255)
GREEN = (80, 255, 130)
RED = (255, 55, 55)
CYAN = (65, 220, 255)
DARK = (8, 12, 18)
PANEL = (15, 24, 32)
YELLOW = (255, 210, 65)

modules = {
    "Nightvision": False,
    "Human Detector": False,
    "Threat Detector": False,
    "Thermal Vision": False,
    "Motion Tracker": False,
    "Digital Zoom": False,
    "Radar Scanner": False,
    "Edge Detection": False,
    "Event Recorder": False,
    "Target Lock": False,
    "Range Finder": False,
    "Signal Scanner": False,
    "Snapshot / Freeze Frame": False,
    "Image Stabilizer": False,
    "System Diagnostics": False,
    "Echo Scan": False,
    "Ghost Trail": False,
    "Power Saver": False,
    "LIDAR Scan": False,
    "Object Classification": False,
    "Motion Vector": False,
    "Coordinate Grid": False,
    "Light Analyzer": False,
    "Proximity Alert": False,
    "Interference Detector": False,
    "Session Timeline": False,
    "Split View": False,
    "Detail Enhancer": False,
    "Overload Protection": False,
    "Track History": False,
    "Minimal HUD": False,
    "LIDAR 2.0 — Point Cloud": False,
    "Surface Reconstruction": False,
    "Multi-Pass Scan": False,
    "Pixel Inspector": False,
    "Pixel Counter": False,
    "Object Ruler": False,
    "Resolution Destroyer": False,
    "Binary Vision": False,
    "Brightness Seismograph": False,
    "Quantum Scanner": False,
    "Ransom Module": False,
    "Error Module": False,
    "Space Module": False,
    "Anomaly Module": False,
    "Power Module": False,
}

powered = False
menu_open = False
battery_level = 100.0
last_battery_update = time.time()
camera = None
CAMERA_POWER_COOLDOWN = 0.8  # Minimum seconds between manual power toggles
last_power_toggle_time = 0.0
last_frame = None
previous_gray = None
motion_mask = None
zoom_level = 1.0
zoom_center_x = 0.5
zoom_center_y = 0.5
thermal_palette_index = 0
thermal_intensity = 1.0
last_auto_snapshot_time = 0.0
last_static_time = 0.0
last_alert_time = 0.0
alert_text = ""
alert_until = 0.0
next_track_id = 1
tracks = {}  # id -> (x, y, last_seen_time)
last_log_event = None
last_yolo_run = 0.0
yolo_boxes_cache = []  # cached (x1, y1, x2, y2, label) results
last_human_run = 0.0
human_boxes_cache = []
frozen_frame_rgb = None
freeze_active = False
last_display_frame_rgb = None
motion_trails = []  # (x, y, timestamp)
lidar_sweep_y = 0
signal_sweep_x = 0
stabilizer_prev_gray = None
stabilizer_prev_points = None
frame_process_ms = 0.0
current_fps = 0.0
classification_boxes_cache = []
last_classification_run = 0.0
motion_vector_previous = {}
track_history_points = []
point_cloud = []  # accumulated (x, y, timestamp) LIDAR-style edge points
multipass_points = []
multipass_progress = 0
pixel_counter_color = None
pixel_counter_count = 0
ruler_points = []
pixel_block_size = 16
brightness_history = []
quantum_frame_counter = 0

# Space Module state
space_scan_active = False   # R: movement + LIDAR-style scan
space_nv_active = False     # Q: night vision + object/distance detection
space_cloud = []            # (x, y, timestamp)
space_sweep_y = 0
space_yolo_cache = []
space_last_yolo = 0.0

# Added module minigames and power-management state.
active_minigame = None             # None, "radar", "thermal", "signal", or "anomaly"
minigame_started = 0.0
minigame_deadline = 0.0
minigame_target = (0, 0)           # Camera-relative target coordinates
minigame_message = ""
minigame_message_until = 0.0
minigame_signal_target = 50
minigame_signal_value = 50
minigame_rounds_won = 0
power_shield_until = 0.0
power_shield_cooldown_until = 0.0

# Ransom challenge state. This is entirely in-app; it never downloads or runs files.
RANSOM_GOAL = 500                 # points needed; each coin gives 5 points
RANSOM_POINTS_PER_COIN = 5
RANSOM_TIME_LIMIT = 90.0           # 1:30 collection timer
ransom_coins_collected = 0         # displayed score/points
ransom_coin_positions = []        # (x, y, radius, unique_id)
ransom_next_coin_time = time.time() + 1.5
ransom_coin_id = 0
ransom_next_roll_time = time.time() + 10.0
ransom_stop_active = False
ransom_stop_started = 0.0
RANSOM_STOP_DURATION = 2.5
ransom_failed = False
ransom_survived = False
ransom_fake_download_until = 0.0
ransom_status_message = "ENABLE RANSOM MODULE + MOTION TRACKER"
ransom_red_static_frames = []
ransom_red_frame_index = 0
ransom_red_last_refresh = 0.0
ransom_red_alpha = 60
ransom_red_alpha_until = 0.0
ransom_fail_static_alpha = None
ransom_phase = "idle"
ransom_phase_started = 0.0
ransom_download_progress = 0
ransom_collect_started = 0.0
ransom_fail_static_started = 0.0
ransom_last_logic_time = time.time()
RANSOM_DOWNLOAD_CHUNKS = 5          # five large chunks, one fifth each
RANSOM_DOWNLOAD_DURATION = 0.35      # very fast simulated download
recent_timeline_events = []
selected_module = "Nightvision"
module_scroll_offset = 0
module_list_area = pygame.Rect(40, 145, 440, 365)
module_info_area = pygame.Rect(500, 145, 460, 365)

MODULE_INFO = {
    "Nightvision": ("Boosts visibility with a green night-vision-style filter.", "Low-medium"),
    "Human Detector": ("Finds possible faces and full-body shapes. Boxes are visual estimates, not identity recognition.", "High"),
    "Threat Detector": ("Flags movement in the configured restricted zone and selected objects. It cannot infer intent.", "Very high"),
    "Thermal Vision": ("Applies a thermal-style false-color filter; it does not measure real temperature.", "Medium-high"),
    "Motion Tracker": ("Draws boxes and temporary IDs around moving image regions.", "Medium"),
    "Digital Zoom": ("Magnifies the center of the camera image using digital cropping.", "Very low"),
    "Radar Scanner": ("Plots detected motion regions on a decorative radar display.", "Low"),
    "Edge Detection": ("Highlights strong edges and outlines in the camera image.", "Medium"),
    "Event Recorder": ("Writes motion and alert events to logs/scanner_events.csv.", "Very low"),
    "Target Lock": ("Highlights the detection closest to the center of the image.", "Medium"),
    "Range Finder": ("Estimates near/medium/far from apparent image size, not calibrated distance.", "Low"),
    "Signal Scanner": ("Sweeps a line across the image and displays a motion-based signal estimate.", "Low"),
    "Snapshot / Freeze Frame": ("Space freezes/resumes the image; S saves a PNG snapshot.", "Very low"),
    "Image Stabilizer": ("Attempts to reduce small camera movement using optical flow.", "High"),
    "System Diagnostics": ("Displays FPS, processing time, and camera resolution.", "Very low"),
    "Echo Scan": ("Adds animated scan lines and expanding rings as a visual effect.", "Medium"),
    "Ghost Trail": ("Leaves short-lived markers behind moving image regions.", "Medium"),
    "Power Saver": ("Reduces overall battery drain and allows slower processing.", "Power saving"),
    "LIDAR Scan": ("Simulates a laser-like edge sweep. A regular webcam cannot measure true depth.", "High"),
    "Object Classification": ("Uses YOLO to label visible objects when the model is available.", "Very high"),
    "Motion Vector": ("Draws arrows showing the estimated direction of moving regions.", "Medium"),
    "Coordinate Grid": ("Overlays an X/Y grid for visual position reference.", "Very low"),
    "Light Analyzer": ("Measures average image brightness and displays a simple light reading.", "Low"),
    "Proximity Alert": ("Warns when a detected region appears large or grows quickly in the image; this is not real-world ranging.", "Medium"),
    "Interference Detector": ("Flags large brightness changes or unusually blurred frames.", "Low-medium"),
    "Session Timeline": ("Shows recent scanner events recorded during this session.", "Very low"),
    "Split View": ("Shows original and processed images side by side for comparison.", "Low-medium"),
    "Detail Enhancer": ("Applies sharpening and contrast to make visible edges easier to inspect.", "Medium"),
    "Overload Protection": ("Slows expensive detection updates when FPS drops to help prevent lag.", "Very low"),
    "Track History": ("Shows recent positions of moving regions as fading history markers.", "Low-medium"),
    "Minimal HUD": ("Hides extra HUD text for a cleaner camera view.", "Very low"),
    "LIDAR 2.0 — Point Cloud": ("Accumulates sampled edge points into a green point-cloud effect. Webcam imagery does not provide true depth.", "Very high"),
    "Surface Reconstruction": ("Builds an approximate wireframe from image edges; it is a 2D visual approximation, not real 3D geometry.", "High"),
    "Multi-Pass Scan": ("Accumulates multiple simulated LIDAR passes and shows scan progress. Press R to reset the scan.", "High"),
    "Pixel Inspector": ("Move the mouse over the camera image to inspect pixel RGB, brightness, and coordinates.", "Very low"),
    "Pixel Counter": ("Counts pixels similar to the color sampled with a left-click on the camera image.", "Low"),
    "Object Ruler": ("Click two points on the camera image to measure their pixel distance. Press C to clear the measurement.", "Very low"),
    "Resolution Destroyer": ("Pixelates the live feed at selectable block sizes. Press [ and ] to change pixelation.", "Very low"),
    "Binary Vision": ("Maps image brightness to a scrolling matrix of 0 and 1 characters.", "Low-medium"),
    "Brightness Seismograph": ("Plots recent average brightness values as a live mini graph.", "Very low"),
    "Quantum Scanner": ("A fictional glitch effect that shifts small image tiles using real image-processing operations.", "Medium"),
    "Ransom Module": ("Requires Motion Tracker. During Blocka90, any visible cyan tracker rectangle counts as movement: A-90 jumpscare (1 second), Stareman2 flash, then download + coin challenge. If no cyan tracker rectangle appears, Stareman3 flashes briefly and the red static/event ends. The 1:30 coin timer can still trigger the three-minute fading static on timeout. This is a simulated in-app event; no files are downloaded.", "Medium-high"),
    "Error Module": ("Distorts the camera with an animated purple-to-pink color corruption, RGB split, glitch strips and scanlines. Loops BEEPERROR while enabled.", "Medium"),
    "Space Module": ("Green low-noise vision. R toggles a movement + LIDAR-style point-cloud scan (Space_E). Q toggles night vision with object and estimated-distance detection (c-moon gravity shift). Distances are estimates from a normal webcam, not real depth.", "Medium-high"),
    "Anomaly Module": ("Anomaly hunt minigame. Press A to begin, then click a moving region outlined in magenta before the 15-second timer ends. Uses camera motion regions; it does not identify supernatural events.", "Medium"),
    "Power Module": ("Power management utility. Press P to activate a 15-second power shield that greatly reduces battery drain. It has a 30-second cooldown; the status appears above the battery meter.", "Low"),
}

# Visual static effects
POWER_ON_DELAY = 0.25  # Brief pause so the camera worker can deliver a frame.
POWER_STATIC_DURATION = 1.0  # Green startup static fades out over one second.
POWER_STATIC_START = None
POWER_STATIC_ACTIVE = False
# T toggles low-volume scanner ambience; quieter operation costs extra battery.
AMBIENCE_NORMAL_VOLUME = 1.0
AMBIENCE_SILENT_VOLUME = 0.15  # 15% volume, within the requested 10-20% range.
SILENT_AMBIENCE_DRAIN_MULTIPLIER = 5.0
AMBIENCE_VOLUME_TRANSITION_SECONDS = 0.45  # Smooth fade in either direction.
ambience_silent_mode = False
ambience_volume_current = AMBIENCE_NORMAL_VOLUME
ambience_volume_from = AMBIENCE_NORMAL_VOLUME
ambience_volume_target = AMBIENCE_NORMAL_VOLUME
ambience_volume_transition_start = 0.0
last_noise_refresh = 0.0
scanner_static_surface = None
power_static_surface = None

# ---------------------------- Assets ----------------------------

def load_sound(filename):
    path = os.path.join(AUDIO_DIR, filename)
    if not os.path.isfile(path):
        print(f"[NVCS] Sound not found: {path}")
        return None
    try:
        return pygame.mixer.Sound(path)
    except (pygame.error, OSError) as exc:
        print(f"[NVCS] Could not load sound {filename}: {exc}")
        return None

sound_equip = load_sound("Scanner_equip.mp3.mp3")
sound_unequip = load_sound("Scanner_unequip.mp3.mp3")
sound_static = load_sound("Scanner_static.mp3.mp3")
sound_static1 = load_sound("Scanner_Ambience.mp3")
if sound_static1 is not None:
    sound_static1.set_volume(AMBIENCE_NORMAL_VOLUME)
sound_censor = load_sound("Scanner_CensorIdle.mp3.mp3")

# Error module sound: assets/audio/Error/BEEPERROR.mp3
sound_error = load_sound(os.path.join("Error", "BEEPERROR.mp3"))

# Space module sounds: assets/audio/Space/
sound_space_e = load_sound(os.path.join("Space", "Space_E.mp3"))
sound_cmoon = load_sound(os.path.join("Space", "c-moon-gravity-shift.mp3"))

# Ransom audio sequence. Files belong in assets/audio/Ransom/.
sound_ransom_glitchy = load_sound(os.path.join("Ransom", "Glitchybefore.mp3"))
sound_ransom_start = load_sound(os.path.join("Ransom", "Ransom_start.mp3"))
sound_ransom_r4nsom = load_sound(os.path.join("Ransom", "R4NSOM.mp3"))
sound_ransom_encounter = load_sound(os.path.join("Ransom", "Ransom_encounter.mp3"))
sound_ransom_jumpscare2 = load_sound(os.path.join("Ransom", "Ransom_jumpscare_2.mp3"))
sound_ransom_success = load_sound(os.path.join("Ransom", "Ransom_success.mp3"))
try:
    ransom_audio_channel = pygame.mixer.Channel(1)
except pygame.error:
    ransom_audio_channel = None
# Absolute deadlines are measured from the movement event, not from when
# another audio file finishes. Playback starts on the first frame at/after each deadline.
ransom_audio_r4nsom_due = None
ransom_audio_encounter_due = None
ransom_audio_encounter_played = False
ransom_block_movement_detected = False

static_path = os.path.join(IMAGE_DIR, "static.jpg")
static_surface = None
if os.path.isfile(static_path):
    try:
        static_img = pygame.image.load(static_path).convert()
        static_surface = pygame.transform.smoothscale(static_img, (CAM_W, CAM_H))
    except pygame.error as exc:
        print(f"[NVCS] Static image could not load: {exc}")

# -------------------------- Detectors ---------------------------
face_detector = None
try:
    cascade_path = os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml")
    face_detector = cv2.CascadeClassifier(cascade_path)
    if face_detector.empty():
        face_detector = None
        print("[NVCS] Face detector failed to load.")
    else:
        print("[NVCS] Face detector loaded.")
except Exception as exc:
    print(f"[NVCS] Face detector unavailable: {exc}")

hog_detector = cv2.HOGDescriptor()
hog_detector.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

model = None
if YOLO is not None:
    if os.path.isfile(MODEL_PATH):
        try:
            model = YOLO(MODEL_PATH)
            print(f"[NVCS] YOLO loaded: {MODEL_PATH}")
        except Exception as exc:
            print(f"[NVCS] YOLO model failed to load: {exc}")
    else:
        print(f"[NVCS] YOLO model not found at: {MODEL_PATH}")
        print("[NVCS] You can place yolov8n.pt in assets/model/.")
else:
    print("[NVCS] Ultralytics unavailable. Motion detection will still work.")

# --------------------------- Utilities --------------------------

def log_event(event, details=""):
    recent_timeline_events.append((datetime.now().strftime("%H:%M:%S"), str(event), str(details)))
    del recent_timeline_events[:-8]
    os.makedirs(LOG_DIR, exist_ok=True)
    new_file = not os.path.exists(LOG_PATH)
    try:
        with open(LOG_PATH, "a", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            if new_file:
                writer.writerow(["timestamp", "event", "details"])
            writer.writerow([datetime.now().isoformat(timespec="seconds"), event, details])
    except OSError as exc:
        print(f"[NVCS] Could not write event log: {exc}")


def draw_text(surface, text, x, y, color=WHITE, font=FONT):
    surface.blit(font.render(str(text), True, color), (x, y))


# ---------------------------- Error Module ----------------------------

def apply_error_effect(frame):
    """Purple-to-pink corruption with glitch strips, RGB split and scanlines."""
    output = frame.copy()
    height, width = output.shape[:2]
    t = time.time()

    # Animated purple -> pink gradient (BGR) sliding across the image.
    purple = np.array([200, 0, 140], dtype=np.float32)
    pink = np.array([200, 105, 255], dtype=np.float32)
    mix = 0.5 + 0.5 * np.sin(np.linspace(0, 2 * np.pi, width, dtype=np.float32) + t * 2.0)
    tint = purple[None, None, :] + (pink - purple)[None, None, :] * mix[None, :, None]
    output = np.clip(output.astype(np.float32) * 0.62 + tint * 0.38, 0, 255).astype(np.uint8)

    # RGB channel split.
    shift = random.randint(3, 9)
    output[:, :, 0] = np.roll(output[:, :, 0], shift, axis=1)
    output[:, :, 2] = np.roll(output[:, :, 2], -shift, axis=1)

    # Horizontal glitch strips.
    if random.random() < 0.65:
        for _ in range(random.randint(1, 4)):
            y = random.randint(0, height - 1)
            y2 = min(height, y + random.randint(2, 12))
            output[y:y2] = np.roll(output[y:y2], random.randint(-35, 35), axis=1)

    # Displaced block.
    if random.random() < 0.35:
        bw, bh = random.randint(60, 220), random.randint(15, 60)
        x = random.randint(0, max(0, width - bw))
        y = random.randint(0, max(0, height - bh))
        x2 = max(0, min(width - bw, x + random.randint(-40, 40)))
        output[y:y + bh, x2:x2 + bw] = output[y:y + bh, x:x + bw].copy()

    # Pink corruption line.
    if random.random() < 0.4:
        y = random.randint(0, height - 1)
        cv2.line(output, (0, y), (width - 1, y), (255, 100, 255), random.randint(1, 3))

    # Scanlines.
    output[::3] = (output[::3] * 0.75).astype(np.uint8)
    return output


def update_error_audio():
    if not pygame.mixer.get_init() or sound_error is None:
        return

    if modules.get("Error Module", False) and powered:
        # Play when enabled; keep looping.
        if sound_error.get_num_channels() == 0:
            sound_error.play(loops=-1)
    else:
        # Stop when disabled or powered off.
        sound_error.stop()


# ---------------------------- Space Module ----------------------------
SPACE_CLAHE = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
_yy, _xx = np.ogrid[:CAM_H, :CAM_W]
_d = np.sqrt(((_xx - CAM_W / 2) / (CAM_W / 2)) ** 2 + ((_yy - CAM_H / 2) / (CAM_H / 2)) ** 2)
SPACE_VIGNETTE = np.clip(1.25 - 0.55 * _d, 0.45, 1.0).astype(np.float32)[:, :, None]

# Approximate real-world heights (m) for a pinhole distance estimate.
SPACE_KNOWN_HEIGHTS_M = {
    "person": 1.7, "chair": 0.9, "bottle": 0.25, "cup": 0.10,
    "cell phone": 0.15, "tv": 0.5, "laptop": 0.25, "book": 0.22,
}
SPACE_FOCAL_PX = 640  # rough webcam focal length at 800px width; tweak to calibrate


def update_space_audio():
    """Stop Space sounds/modes whenever the module is off or the scanner is powered down."""
    global space_scan_active, space_nv_active
    if modules.get("Space Module", False) and powered:
        return
    space_scan_active = False
    space_nv_active = False
    for snd in (sound_space_e, sound_cmoon):
        if snd:
            snd.stop()


def apply_space_base(frame):
    """Green, clearer vision: edge-preserving denoise + sharpen + local contrast."""
    clean = cv2.bilateralFilter(frame, 5, 40, 40)
    soft = cv2.GaussianBlur(clean, (0, 0), 1.5)
    clean = cv2.addWeighted(clean, 1.5, soft, -0.5, 0)
    g = SPACE_CLAHE.apply(cv2.cvtColor(clean, cv2.COLOR_BGR2GRAY))
    out = np.zeros_like(frame)
    out[:, :, 1] = g
    out[:, :, 0] = (g * 0.12).astype(np.uint8)
    out[:, :, 2] = (g * 0.18).astype(np.uint8)
    return out


def apply_space_nightvision(frame):
    """Q mode: strong amplified night vision with grain and vignette."""
    g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    g = cv2.equalizeHist(cv2.GaussianBlur(g, (3, 3), 0))
    g = cv2.add(g, np.random.randint(0, 18, g.shape, dtype=np.uint8))
    out = np.zeros_like(frame)
    out[:, :, 1] = g
    out[:, :, 0] = (g * 0.05).astype(np.uint8)
    out[:, :, 2] = (g * 0.10).astype(np.uint8)
    return (out * SPACE_VIGNETTE).astype(np.uint8)


def draw_space_scan(frame, gray, motion_boxes):
    """R mode: movement boxes + LIDAR-style point cloud built from edges (not true depth)."""
    global space_sweep_y
    t = time.time()
    space_sweep_y = (space_sweep_y + 6) % CAM_H
    y0 = max(0, space_sweep_y - 4)
    band = cv2.Canny(gray, 80, 160)[y0:space_sweep_y + 5, :]
    ys, xs = np.where(band > 0)
    ys = ys + y0
    if len(xs) > 300:
        idx = np.linspace(0, len(xs) - 1, 300).astype(int)
        xs, ys = xs[idx], ys[idx]
    for x, y in zip(xs, ys):
        space_cloud.append((int(x), int(y), t))
    space_cloud[:] = [p for p in space_cloud if t - p[2] < 4.0][-3000:]
    for x, y, pt in space_cloud[::2]:
        fade = max(0.15, 1.0 - (t - pt) / 4.0)
        cv2.circle(frame, (x, y), 1, (int(90 * fade), int(255 * fade), int(120 * fade)), -1)
    cv2.line(frame, (0, space_sweep_y), (CAM_W - 1, space_sweep_y), (120, 255, 160), 2)
    for (x, y, w, h) in motion_boxes:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (120, 255, 160), 2)
        cv2.putText(frame, "MOVEMENT", (x, max(15, y - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (120, 255, 160), 1)
    cv2.putText(frame, f"MOVEMENT: {len(motion_boxes)}  CLOUD: {len(space_cloud)} PTS",
                (12, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (120, 255, 160), 1)


def draw_space_objects(frame, source_frame, motion_boxes):
    """Q mode: object boxes with estimated distance (YOLO if available, else motion size)."""
    global space_yolo_cache, space_last_yolo
    t = time.time()
    if model is not None:
        if t - space_last_yolo >= 0.6:
            cache = []
            try:
                for result in model.predict(source_frame, verbose=False, conf=0.4, imgsz=416):
                    for box in result.boxes:
                        x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                        cls_id = int(box.cls[0])
                        cache.append((x1, y1, x2, y2, str(result.names.get(cls_id, cls_id))))
            except Exception as exc:
                print(f"[NVCS] Space object detection issue: {exc}")
            space_yolo_cache = cache[:15]
            space_last_yolo = t
        detections = space_yolo_cache
    else:
        detections = [(x, y, x + w, y + h, "OBJECT") for x, y, w, h in motion_boxes]

    for x1, y1, x2, y2, label in detections:
        bw, bh = max(1, x2 - x1), max(1, y2 - y1)
        known = SPACE_KNOWN_HEIGHTS_M.get(label)
        if known:
            dist = f"~{known * SPACE_FOCAL_PX / bh:.1f}m"
        else:
            ratio = (bw * bh) / float(CAM_W * CAM_H)
            dist = "NEAR" if ratio > 0.12 else ("MID" if ratio > 0.035 else "FAR")
        cv2.rectangle(frame, (x1, y1), (x2, y2), (140, 255, 170), 2)
        cv2.putText(frame, f"{label.upper()} {dist}", (x1, max(16, y1 - 6)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (140, 255, 170), 2)
    cv2.putText(frame, "NIGHT VISION / DISTANCE ESTIMATE", (12, 42),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (140, 255, 170), 1)


def trigger_alert(message):
    global alert_text, alert_until, last_alert_time
    alert_text = message
    alert_until = time.time() + 2.5
    if time.time() - last_alert_time > 1.5:
        log_event("THREAT ALERT", message)
        last_alert_time = time.time()
        if sound_censor:
            sound_censor.play()


def make_green_static_surface():
    """Create a green static frame cheaply at quarter resolution, then scale it once."""
    small_w, small_h = CAM_W // 4, CAM_H // 4
    noise = np.random.randint(0, 256, (small_h, small_w), dtype=np.uint8)
    green = np.zeros((small_h, small_w, 3), dtype=np.uint8)
    green[:, :, 1] = (noise * 0.78).astype(np.uint8)
    green[:, :, 0] = (noise * 0.035).astype(np.uint8)
    green[:, :, 2] = (noise * 0.12).astype(np.uint8)
    rgb = cv2.cvtColor(green, cv2.COLOR_BGR2RGB)
    small_surface = pygame.surfarray.make_surface(np.transpose(rgb, (1, 0, 2)))
    return pygame.transform.scale(small_surface, (CAM_W, CAM_H))


# Pre-generate a few static frames once. Reusing these avoids generating 288,000
# random pixels repeatedly while the scanner is running or being toggled.
STATIC_FRAMES = [make_green_static_surface() for _ in range(5)]
static_frame_index = 0


def make_red_static_surface():
    """Pre-render red corruption static for the Ransom failure state."""
    small_w, small_h = CAM_W // 4, CAM_H // 4
    noise = np.random.randint(0, 256, (small_h, small_w), dtype=np.uint8)
    red = np.zeros((small_h, small_w, 3), dtype=np.uint8)
    red[:, :, 2] = noise
    red[:, :, 1] = (noise * 0.025).astype(np.uint8)
    red[:, :, 0] = (noise * 0.04).astype(np.uint8)
    rgb = cv2.cvtColor(red, cv2.COLOR_BGR2RGB)
    small_surface = pygame.surfarray.make_surface(np.transpose(rgb, (1, 0, 2)))
    return pygame.transform.scale(small_surface, (CAM_W, CAM_H))


RANSOM_RED_FRAMES = [make_red_static_surface() for _ in range(5)]

def load_ransom_image(filename_stem):
    """Load a Ransom image from assets/Image/Ransom, tolerating omitted extensions/case differences."""
    ransom_image_dir = os.path.join(IMAGE_DIR, "Ransom")
    if not os.path.isdir(ransom_image_dir):
        print(f"[NVCS] Ransom image folder not found: {ransom_image_dir}")
        return None
    wanted = filename_stem.lower()
    try:
        names = os.listdir(ransom_image_dir)
    except OSError:
        return None
    candidates = [wanted] if os.path.splitext(wanted)[1] else [wanted + ext for ext in (".png", ".webp", ".jpg", ".jpeg")]
    for name in names:
        low = name.lower()
        if low in candidates or (not os.path.splitext(wanted)[1] and os.path.splitext(low)[0] == wanted):
            try:
                image = pygame.image.load(os.path.join(ransom_image_dir, name)).convert_alpha()
                return pygame.transform.smoothscale(image, (180, 180))
            except (pygame.error, OSError):
                print(f"[NVCS] Could not load Ransom image: {name}")
    print(f"[NVCS] Ransom image not found in assets/Image/Ransom: {filename_stem}")
    return None

RANSOM_IMAGES = {
    "idle": load_ransom_image("A-90_IDLE.png"),
    "block": load_ransom_image("Blocka90.png"),
    "safe_flash": load_ransom_image("Thestareman3_red2.png"),
    "jumpscare": load_ransom_image("A-90_JUMPSCARE"),
    "stare2": load_ransom_image("Thestareman2_red"),
    "thanks": load_ransom_image("Ransomthanks.webp"),
    "coin": load_ransom_image("coin.png"),
}


class SafeCamera:
    """Webcam capture on a daemon thread, with backend/index fallbacks."""
    def __init__(self, index=0):
        import threading
        self.index = index
        self._threading = threading
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._capture = None
        self._frame = None
        self._opened = False
        self.failed = False
        self.error = None
        self.status = "Starting camera..."
        # Ask for a common webcam mode first; the displayed image is resized
        # to NVCS's 800x360 viewport after capture.
        self._settings = [
            (cv2.CAP_PROP_FRAME_WIDTH, 640),
            (cv2.CAP_PROP_FRAME_HEIGHT, 480),
            (cv2.CAP_PROP_BUFFERSIZE, 1),
        ]
        self._thread = threading.Thread(target=self._worker, daemon=True, name="NVCS-Webcam")
        self._thread.start()

    def _worker(self):
        cap = None
        last_error = None
        # Windows laptops and USB/virtual cameras can require different backends
        # or camera indices. Try each option off the Pygame thread.
        if os.name == "nt":
            # Try the usual built-in webcam quickly before checking other devices.
            backends = [cv2.CAP_DSHOW, cv2.CAP_MSMF, cv2.CAP_ANY]
            indices = list(dict.fromkeys([self.index, 1, 2, 3]))
        else:
            backends = [cv2.CAP_ANY]
            indices = list(dict.fromkeys([self.index, 1, 2, 3]))

        try:
            for camera_index in indices:
                for backend in backends:
                    if self._stop.is_set():
                        return
                    candidate = None
                    backend_name = {cv2.CAP_DSHOW: "DirectShow", cv2.CAP_MSMF: "Media Foundation", cv2.CAP_ANY: "automatic"}.get(backend, str(backend))
                    self.status = f"Trying camera {camera_index} ({backend_name})..."
                    try:
                        candidate = cv2.VideoCapture(camera_index, backend)
                        if candidate is None or not candidate.isOpened():
                            last_error = f"Camera {camera_index} could not open with {backend_name}"
                            if candidate is not None:
                                candidate.release()
                            continue
                        for prop, value in self._settings:
                            try:
                                candidate.set(prop, value)
                            except Exception:
                                pass

                        # Do not accept a backend just because isOpened() is true:
                        # some drivers open successfully but never return frames.
                        # This validation happens here, never on the UI thread.
                        frame = None
                        for _ in range(6):
                            if self._stop.is_set():
                                candidate.release()
                                return
                            ok, test_frame = candidate.read()
                            if ok and test_frame is not None and getattr(test_frame, "size", 0) > 0:
                                frame = test_frame
                                break
                            self._stop.wait(0.04)
                        if frame is None:
                            last_error = f"Camera {camera_index} opened with {backend_name}, but returned no frames"
                            candidate.release()
                            continue

                        cap = candidate
                        with self._lock:
                            self._capture = cap
                            self._frame = frame
                            self._opened = True
                        self.status = f"Camera {camera_index} connected ({backend_name})"
                        break
                    except Exception as exc:
                        last_error = f"Camera {camera_index}, backend {backend_name}: {exc}"
                        try:
                            if candidate is not None:
                                candidate.release()
                        except Exception:
                            pass
                if cap is not None:
                    break

            if cap is None:
                self.failed = True
                self.error = last_error or "No camera found. Check permissions, connection, and camera index."
                self.status = "Camera unavailable"
                return

            while not self._stop.is_set():
                try:
                    ok, frame = cap.read()
                    if ok and frame is not None and getattr(frame, "size", 0) > 0:
                        with self._lock:
                            self._frame = frame
                    else:
                        # Count consecutive read failures rather than spin forever.
                        self._stop.wait(0.04)
                except Exception as exc:
                    self.error = str(exc)
                    self.failed = True
                    self.status = "Camera read error"
                    break
        except Exception as exc:
            self.error = str(exc)
            self.failed = True
            self.status = "Camera startup error"
        finally:
            if cap is not None:
                try:
                    cap.release()
                except Exception:
                    pass
            with self._lock:
                self._capture = None
                self._opened = False

    def isOpened(self):
        return not self.failed and not self._stop.is_set()

    def set(self, prop, value):
        # Queue settings safely; they are applied when each backend is opened.
        with self._lock:
            self._settings.append((prop, value))
            cap = self._capture
        if cap is not None:
            try:
                return cap.set(prop, value)
            except Exception:
                return False
        return True

    def read(self):
        with self._lock:
            frame = self._frame
            opened = self._opened
        if frame is None or not opened:
            return False, None
        return True, frame.copy()

    def release(self):
        # Do not call cap.release() from the UI thread while another thread is
        # blocked in cap.read(); signal the worker and let it release its handle.
        self._stop.set()

# Warm up the webcam while NVCS starts, so pressing F usually shows a live
# frame immediately. The camera remains active while the scanner is in standby.
# Close NVCS to release the webcam completely.
camera = SafeCamera(0)

def toggle_power(force=False):
    global powered, camera, previous_gray, tracks, zoom_level
    global POWER_STATIC_START, POWER_STATIC_ACTIVE, power_static_surface
    global battery_level, static_frame_index, last_power_toggle_time
    now = time.monotonic()
    if not force and now - last_power_toggle_time < CAMERA_POWER_COOLDOWN:
        # Silent cooldown: ignore rapid F presses without showing an alert.
        return
    if not powered and battery_level <= 0:
        trigger_alert("BATTERY DEPLETED - RECHARGING")
        return

    last_power_toggle_time = now
    # On startup, leave a short pause before the green static. The webcam keeps
    # warming up in the background during this pause, then the static fades away.
    POWER_STATIC_START = time.time() + POWER_ON_DELAY if not powered else time.time()
    POWER_STATIC_ACTIVE = True
    static_frame_index = random.randrange(len(STATIC_FRAMES))
    power_static_surface = STATIC_FRAMES[static_frame_index]
    if powered:
        powered = False
        global freeze_active, frozen_frame_rgb
        freeze_active = False
        frozen_frame_rgb = None
        # Keep the webcam warmed up in standby so the next power-on is fast.
        # It is released only when NVCS exits (or if the camera errors).
        previous_gray = None
        tracks.clear()
        # Stop scanner ambience immediately when powering off.
        if sound_static:
            sound_static.stop()
        if sound_static1:
            sound_static1.stop()
        if sound_unequip:
            sound_unequip.play()
        log_event("Scanner powered off")
    else:
        # Reuse the already-warmed webcam. If it failed or was released, retry.
        if camera is None or getattr(camera, "failed", False):
            if camera is not None:
                camera.release()
            camera = SafeCamera(0)
        powered = True
        zoom_level = 1.0
        if sound_static:
            sound_static.play(loops=-1)
        if sound_static1:
            sound_static1.play(loops=-1)
        if sound_equip:
            sound_equip.play()
        log_event("Scanner powered on")

def zoom_frame(frame):
    if zoom_level <= 1.001:
        return frame
    h, w = frame.shape[:2]
    crop_w = max(1, int(w / zoom_level))
    crop_h = max(1, int(h / zoom_level))
    x1 = int((w - crop_w) * zoom_center_x)
    y1 = int((h - crop_h) * zoom_center_y)
    x1 = max(0, min(w - crop_w, x1))
    y1 = max(0, min(h - crop_h, y1))
    cropped = frame[y1:y1 + crop_h, x1:x1 + crop_w]
    return cv2.resize(cropped, (w, h), interpolation=cv2.INTER_LINEAR)


def detect_skin_regions(frame):
    # Approximate skin-color regions; this is a visual heuristic, not identity recognition.
    ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
    mask = cv2.inRange(ycrcb, np.array([0, 133, 77]), np.array([255, 173, 127]))
    mask = cv2.medianBlur(mask, 5)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    boxes = []
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        if w >= 35 and h >= 35 and w * h >= 1800:
            boxes.append((x, y, w, h))
    return boxes


def match_tracks(boxes):
    global next_track_id, tracks
    now = time.time()
    new_tracks = {}
    used_ids = set()
    for box in boxes:
        x, y, w, h = box
        cx, cy = x + w // 2, y + h // 2
        best_id, best_dist = None, 65
        for track_id, (tx, ty, seen) in tracks.items():
            if track_id in used_ids or now - seen > 1.0:
                continue
            dist = math.hypot(cx - tx, cy - ty)
            if dist < best_dist:
                best_dist, best_id = dist, track_id
        if best_id is None:
            best_id = next_track_id
            next_track_id += 1
        used_ids.add(best_id)
        new_tracks[best_id] = (cx, cy, now)
        yield best_id, box
    tracks = new_tracks


def menu_buttons():
    """Visible, scrollable module rows in the left half of the module menu."""
    labels = list(modules.keys())
    buttons = []
    row_h = 29
    visible_rows = max(1, (module_list_area.height - 8) // row_h)
    first = max(0, min(module_scroll_offset, max(0, len(labels) - visible_rows)))
    for visible_index, module_index in enumerate(range(first, min(len(labels), first + visible_rows))):
        name = labels[module_index]
        rect = pygame.Rect(module_list_area.x + 8, module_list_area.y + 4 + visible_index * row_h, module_list_area.width - 16, row_h - 3)
        buttons.append((name, rect))
    return buttons

# ----------------------------- Main -----------------------------
menu_overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
menu_overlay.fill((0, 0, 0, 205))

running = True
while running:
    clock.tick(FPS_LIMIT)
    screen.fill(DARK)

    # Smoothly fade BOTH scanner ambience sounds between normal and low volume.
    # This is updated every frame, so toggling T never causes a sudden volume jump.
    now_for_ambience = time.time()
    if ambience_volume_transition_start > 0.0:
        transition_progress = min(
            1.0,
            max(0.0, (now_for_ambience - ambience_volume_transition_start) / AMBIENCE_VOLUME_TRANSITION_SECONDS)
        )
        # Smoothstep interpolation avoids a harsh start/stop to the fade.
        eased_progress = transition_progress * transition_progress * (3.0 - 2.0 * transition_progress)
        ambience_volume_current = ambience_volume_from + (ambience_volume_target - ambience_volume_from) * eased_progress
        if transition_progress >= 1.0:
            ambience_volume_current = ambience_volume_target
            ambience_volume_transition_start = 0.0
        if sound_static is not None:
            sound_static.set_volume(ambience_volume_current)
        if sound_static1 is not None:
            sound_static1.set_volume(ambience_volume_current)
        if sound_error is not None:
                sound_error.set_volume(ambience_volume_current)

    # Battery drains slowly while powered and recharges at a moderate rate while off.
    now_for_battery = time.time()
    battery_dt = max(0.0, min(1.0, now_for_battery - last_battery_update))
    last_battery_update = now_for_battery
    if powered:
        # Power Saver reduces overall drain; negative module cost is clamped at zero.
        module_drain = sum(
            cost for name, cost in MODULE_ENERGY_COST.items()
            if modules.get(name, False) and name != "Power Saver"
        )
        if modules.get("Threat Detector", False) and model is None:
            module_drain -= MODULE_ENERGY_COST["Threat Detector"] * 0.50
        battery_drain_rate = max(0.015, BATTERY_BASE_DRAIN_PER_SECOND + module_drain + MODULE_ENERGY_COST["Power Saver"] * int(modules.get("Power Saver", False)))
        if modules.get("Power Saver", False):
            battery_drain_rate *= 0.60
        if modules.get("Power Module", False) and now_for_battery < power_shield_until:
            battery_drain_rate *= 0.30
        if ambience_silent_mode:
            battery_drain_rate *= SILENT_AMBIENCE_DRAIN_MULTIPLIER
        battery_level = max(0.0, battery_level - battery_drain_rate * battery_dt)
        if battery_level <= 0.0:
            toggle_power(force=True)  # Battery shutdown must bypass the manual cooldown.
            battery_level = 0.0
    else:
        battery_drain_rate = 0.0
        battery_level = min(100.0, battery_level + BATTERY_CHARGE_PER_SECOND * battery_dt)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                if menu_open:
                    menu_open = False
                else:
                    running = False
            elif event.key == pygame.K_f:
                toggle_power()
            elif event.key == pygame.K_e:
                # Module menu is available even when the camera is powered off.
                menu_open = not menu_open
            elif event.key in (pygame.K_EQUALS, pygame.K_PLUS, pygame.K_KP_PLUS):
                zoom_level = min(3.0, zoom_level + 0.2)
            elif event.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
                zoom_level = max(1.0, zoom_level - 0.2)
                if zoom_level <= 1.0:
                    zoom_center_x = 0.5
                    zoom_center_y = 0.5
            elif event.key == pygame.K_0:
                zoom_level = 1.0
                zoom_center_x = 0.5
                zoom_center_y = 0.5
            elif event.key in (pygame.K_LEFT, pygame.K_DOWN) and active_minigame == "signal":
                minigame_signal_value = max(0, min(100, minigame_signal_value - 2))
            elif event.key in (pygame.K_RIGHT, pygame.K_UP) and active_minigame == "signal":
                minigame_signal_value = max(0, min(100, minigame_signal_value + 2))
            elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER) and active_minigame == "signal":
                if abs(minigame_signal_value - minigame_signal_target) <= 4:
                    minigame_message = "SIGNAL LOCKED - SUCCESS"
                    minigame_rounds_won += 1
                    log_event("Signal minigame won", f"Target {minigame_signal_target}, tuned {minigame_signal_value}")
                else:
                    minigame_message = f"SIGNAL MISSED - TARGET {minigame_signal_target}"
                    log_event("Signal minigame missed", f"Target {minigame_signal_target}, tuned {minigame_signal_value}")
                minigame_message_until = time.time() + 2.5
                active_minigame = None
            elif event.key == pygame.K_g and modules.get("Radar Scanner", False) and powered and not menu_open:
                active_minigame = "radar"
                minigame_started = time.time()
                minigame_deadline = minigame_started + 15.0
                # Target is within the small radar circle at the top-right of the camera.
                while True:
                    tx = random.randint(CAM_W - 115, CAM_W - 35)
                    ty = random.randint(35, 115)
                    if math.hypot(tx - (CAM_W - 75), ty - 75) <= 36:
                        minigame_target = (tx, ty)
                        break
                minigame_message = ""
                log_event("Radar minigame started", "Click the target blip")
            elif event.key == pygame.K_t:
                ambience_silent_mode = not ambience_silent_mode
                ambience_volume_from = ambience_volume_current
                ambience_volume_target = AMBIENCE_SILENT_VOLUME if ambience_silent_mode else AMBIENCE_NORMAL_VOLUME
                ambience_volume_transition_start = time.time()
                mode_label = "LOW AMBIENCE (15% VOLUME, 5X BATTERY DRAIN)" if ambience_silent_mode else "NORMAL AMBIENCE RESTORED (FADING IN)"
                log_event("Silent ambience toggled", mode_label)
            elif event.key == pygame.K_h and modules.get("Thermal Vision", False) and powered and not menu_open:
                active_minigame = "thermal"
                minigame_started = time.time()
                minigame_deadline = minigame_started + 12.0
                minigame_target = (random.randint(70, CAM_W - 70), random.randint(55, CAM_H - 55))
                minigame_message = ""
                log_event("Thermal minigame started", "Find and click the hot spot")
            elif event.key == pygame.K_y and modules.get("Signal Scanner", False) and powered and not menu_open:
                active_minigame = "signal"
                minigame_started = time.time()
                minigame_deadline = minigame_started + 20.0
                minigame_signal_target = random.randint(15, 85)
                minigame_signal_value = 50
                minigame_message = ""
                log_event("Signal minigame started", "Tune frequency with arrow keys; Enter to lock")
            elif event.key == pygame.K_a and modules.get("Anomaly Module", False) and powered and not menu_open:
                active_minigame = "anomaly"
                minigame_started = time.time()
                minigame_deadline = minigame_started + 15.0
                minigame_message = ""
                log_event("Anomaly hunt started", "Click a magenta-marked moving region")
            elif event.key == pygame.K_p and modules.get("Power Module", False) and powered and not menu_open:
                power_now = time.time()
                if power_now >= power_shield_cooldown_until:
                    power_shield_until = power_now + 15.0
                    power_shield_cooldown_until = power_now + 45.0
                    minigame_message = "POWER SHIELD ACTIVE - 15 SECONDS"
                    minigame_message_until = power_now + 2.5
                    log_event("Power shield activated", "Battery drain reduced by 70% for 15 seconds")
                else:
                    trigger_alert(f"POWER SHIELD COOLDOWN: {int(power_shield_cooldown_until - power_now)}s")
            elif event.key == pygame.K_v and modules.get("Thermal Vision", False):
                thermal_palette_index = (thermal_palette_index + 1) % 4
            elif event.key == pygame.K_COMMA and modules.get("Thermal Vision", False):
                thermal_intensity = max(0.2, thermal_intensity - 0.1)
            elif event.key == pygame.K_PERIOD and modules.get("Thermal Vision", False):
                thermal_intensity = min(1.0, thermal_intensity + 0.1)
            elif event.key == pygame.K_LEFT and modules.get("Digital Zoom", False) and zoom_level > 1.0:
                zoom_center_x = max(0.0, zoom_center_x - 0.05)
            elif event.key == pygame.K_RIGHT and modules.get("Digital Zoom", False) and zoom_level > 1.0:
                zoom_center_x = min(1.0, zoom_center_x + 0.05)
            elif event.key == pygame.K_UP and modules.get("Digital Zoom", False) and zoom_level > 1.0:
                zoom_center_y = max(0.0, zoom_center_y - 0.05)
            elif event.key == pygame.K_DOWN and modules.get("Digital Zoom", False) and zoom_level > 1.0:
                zoom_center_y = min(1.0, zoom_center_y + 0.05)
            elif event.key == pygame.K_c:
                ruler_points.clear()
            elif event.key == pygame.K_r and modules.get("Space Module", False) and powered:
                # Space Module: movement detection + LIDAR-style scan cloud.
                space_scan_active = not space_scan_active
                space_cloud.clear()
                if sound_space_e:
                    sound_space_e.play() if space_scan_active else sound_space_e.stop()
                log_event("Space scan", "ON" if space_scan_active else "OFF")
            elif event.key == pygame.K_q and modules.get("Space Module", False) and powered:
                # Space Module: night vision + object/distance detection.
                space_nv_active = not space_nv_active
                if sound_cmoon:
                    sound_cmoon.play() if space_nv_active else sound_cmoon.stop()
                log_event("Space night vision", "ON" if space_nv_active else "OFF")
            elif event.key == pygame.K_r and modules.get("Multi-Pass Scan", False):
                multipass_points.clear()
                multipass_progress = 0
            elif event.key == pygame.K_LEFTBRACKET:
                pixel_block_size = min(64, pixel_block_size + 4)
            elif event.key == pygame.K_RIGHTBRACKET:
                pixel_block_size = max(4, pixel_block_size - 4)
            elif event.key == pygame.K_SPACE and modules.get("Snapshot / Freeze Frame", False) and powered:
                freeze_active = not freeze_active
                if freeze_active and last_display_frame_rgb is not None:
                    frozen_frame_rgb = last_display_frame_rgb.copy()
                elif not freeze_active:
                    frozen_frame_rgb = None
                log_event("Freeze frame", "ON" if freeze_active else "OFF")
            elif event.key == pygame.K_s and modules.get("Snapshot / Freeze Frame", False) and (freeze_active or last_display_frame_rgb is not None):
                image_to_save = frozen_frame_rgb if freeze_active else last_display_frame_rgb
                if image_to_save is not None:
                    os.makedirs(os.path.join(BASE_DIR, "snapshots"), exist_ok=True)
                    save_path = os.path.join(BASE_DIR, "snapshots", f"nvcs_snapshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
                    cv2.imwrite(save_path, cv2.cvtColor(image_to_save, cv2.COLOR_RGB2BGR))
                    log_event("Snapshot saved", save_path)
                    trigger_alert("SNAPSHOT SAVED")
        elif event.type == pygame.MOUSEWHEEL and menu_open:
            if module_list_area.collidepoint(pygame.mouse.get_pos()):
                module_scroll_offset = max(0, min(len(modules) - 1, module_scroll_offset - event.y * 3))
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button in (4, 5) and menu_open:
            if module_list_area.collidepoint(event.pos):
                module_scroll_offset = max(0, min(len(modules) - 1, module_scroll_offset + (-3 if event.button == 4 else 3)))
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and menu_open:
            for name, rect in menu_buttons():
                if rect.collidepoint(event.pos):
                    selected_module = name
                    modules[name] = not modules[name]
                    log_event("Module toggled", f"{name}={'ON' if modules[name] else 'OFF'}")
                    if name == "Event Recorder" and modules[name]:
                        log_event("Event Recorder enabled")
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not menu_open and powered:
            mx, my = event.pos
            if CAM_X <= mx < CAM_X + CAM_W and CAM_Y <= my < CAM_Y + CAM_H:
                ix, iy = mx - CAM_X, my - CAM_Y
                # Radar and thermal challenges use camera-relative click positions.
                if active_minigame == "radar" and math.hypot(ix - minigame_target[0], iy - minigame_target[1]) <= 14:
                    active_minigame = None
                    minigame_rounds_won += 1
                    minigame_message = "RADAR TARGET LOCKED"
                    minigame_message_until = time.time() + 2.5
                    log_event("Radar minigame won", f"Target at {ix},{iy}")
                elif active_minigame == "thermal" and math.hypot(ix - minigame_target[0], iy - minigame_target[1]) <= 24:
                    active_minigame = None
                    minigame_rounds_won += 1
                    minigame_message = "THERMAL HOTSPOT FOUND"
                    minigame_message_until = time.time() + 2.5
                    log_event("Thermal minigame won", f"Hotspot at {ix},{iy}")
                elif active_minigame == "anomaly":
                    clicked_anomaly = any(x <= ix <= x + w and y <= iy <= y + h for x, y, w, h in motion_boxes)
                    if clicked_anomaly:
                        active_minigame = None
                        minigame_rounds_won += 1
                        minigame_message = "ANOMALY CONFIRMED"
                        minigame_message_until = time.time() + 2.5
                        log_event("Anomaly hunt won", f"Clicked moving region at {ix},{iy}")
                # Ransom coins are clickable game objects over the camera view.
                if (modules.get("Ransom Module", False) and modules.get("Motion Tracker", False)
                        and ransom_phase == "collect" and not ransom_failed and not ransom_survived):
                    for coin in list(ransom_coin_positions):
                        cx, cy, radius, coin_id = coin
                        if math.hypot(ix - cx, iy - cy) <= radius + 5:
                            ransom_coin_positions.remove(coin)
                            ransom_coins_collected = min(RANSOM_GOAL, ransom_coins_collected + RANSOM_POINTS_PER_COIN)
                            log_event("Ransom coin collected", f"{ransom_coins_collected}/{RANSOM_GOAL} points")
                            if ransom_coins_collected >= RANSOM_GOAL:
                                ransom_survived = True
                                ransom_phase = "success"
                                ransom_phase_started = time.time()
                                ransom_coin_positions.clear()
                                ransom_status_message = "SURVIVED - 500/500 POINTS"
                                if ransom_audio_channel is not None:
                                    ransom_audio_channel.stop()
                                    if sound_ransom_success is not None:
                                        ransom_audio_channel.play(sound_ransom_success)
                                ransom_audio_r4nsom_due = None
                                ransom_audio_encounter_due = None
                                ransom_audio_encounter_played = True
                                log_event("Ransom challenge survived", "Collected 500 points")
                                trigger_alert("RANSOM CHALLENGE SURVIVED")
                            break
                if modules.get("Pixel Counter", False) and last_display_frame_rgb is not None:
                    sample = last_display_frame_rgb[min(CAM_H - 1, iy), min(CAM_W - 1, ix)]
                    pixel_counter_color = tuple(int(v) for v in sample)
                    log_event("Pixel Counter sampled", str(pixel_counter_color))
                if modules.get("Object Ruler", False):
                    ruler_points.append((ix, iy))
                    if len(ruler_points) > 2:
                        ruler_points = [(ix, iy)]

    # Keep looping/ambient module sounds in sync with module state.
    update_error_audio()
    update_space_audio()

    # Resolve timed minigame failures without blocking the camera loop.
    minigame_now = time.time()
    if active_minigame is not None and minigame_now >= minigame_deadline:
        expired_name = active_minigame.upper()
        active_minigame = None
        minigame_message = f"{expired_name} SCAN TIMED OUT"
        minigame_message_until = minigame_now + 2.5
        log_event(f"{expired_name.title()} minigame timed out")

    # Header
    pygame.draw.rect(screen, PANEL, (0, 0, SCREEN_W, 58))
    draw_text(screen, "NVCS 3000 SCANNER", 22, 13, CYAN, TITLE)
    status = "ONLINE" if powered else "STANDBY"
    draw_text(screen, f"SYSTEM: {status}", 750, 18, GREEN if powered else YELLOW)
    draw_text(screen, "F: POWER   T: LOW AMBIENCE / 2.5X DRAIN   E: MODULES   ESC: EXIT/CLOSE MENU", 100, 70, WHITE, SMALL)

    frame_to_show = None
    threat_triggered = False
    threat_reasons = []
    motion_boxes = []
    motion_tracker_boxes = []  # Exact boxes that the Motion Tracker will draw in cyan.
    human_boxes = []

    frame_start_time = time.perf_counter()
    if powered and camera is not None and getattr(camera, "failed", False):
        camera_error = getattr(camera, "error", None)
        print(f"[NVCS] Could not open/read camera: {camera_error or 'unknown camera error'}. Check permissions or close other camera apps.")
        camera.release()
        camera = None
        powered = False
        trigger_alert("CAMERA UNAVAILABLE")
        log_event("Camera unavailable", camera_error or "OpenCV camera startup/read failed")

    if powered and camera is not None:
        ok, frame = camera.read()
        if not ok:
            camera_status = getattr(camera, "status", "Waiting for camera frame...")
            # The scanner powers on immediately; this label is only shown until
            # the webcam delivers its first real frame. Your live image replaces it.
            draw_text(screen, "STARTING LIVE CAMERA...", CAM_X + 265, CAM_Y + 145, YELLOW, SMALL)
            draw_text(screen, camera_status.upper(), CAM_X + 190, CAM_Y + 172, WHITE, SMALL)
        if ok:
            frame = cv2.flip(frame, 1)
            frame = cv2.resize(frame, (CAM_W, CAM_H))
            frame = zoom_frame(frame)
            original_frame = frame.copy()
            fps_for_adaptation = clock.get_fps()
            overload_factor = 2.0 if modules.get("Overload Protection", False) and fps_for_adaptation > 0 and fps_for_adaptation < 18 else 1.0
            if modules.get("Power Saver", False):
                overload_factor *= 1.7
            if modules.get("Image Stabilizer", False):
                # Lightweight translation stabilization from sparse optical flow.
                stable_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                if stabilizer_prev_gray is not None:
                    points = cv2.goodFeaturesToTrack(stabilizer_prev_gray, maxCorners=45, qualityLevel=0.02, minDistance=12, blockSize=7)
                    if points is not None and len(points) >= 5:
                        next_points, status, _ = cv2.calcOpticalFlowPyrLK(stabilizer_prev_gray, stable_gray, points, None, winSize=(15, 15), maxLevel=1)
                        if next_points is not None and status is not None:
                            good_old = points[status.flatten() == 1]
                            good_new = next_points[status.flatten() == 1]
                            if len(good_old) >= 5:
                                shifts = good_new - good_old
                                dx, dy = np.median(shifts, axis=0).flatten()
                                if abs(dx) < 35 and abs(dy) < 35:
                                    matrix = np.float32([[1, 0, -dx], [0, 1, -dy]])
                                    frame = cv2.warpAffine(frame, matrix, (CAM_W, CAM_H), borderMode=cv2.BORDER_REPLICATE)
                stabilizer_prev_gray = stable_gray
            else:
                stabilizer_prev_gray = None
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            gray_blur = cv2.GaussianBlur(gray, (21, 21), 0)

            if previous_gray is not None:
                diff = cv2.absdiff(previous_gray, gray_blur)
                _, motion_mask = cv2.threshold(diff, 24, 255, cv2.THRESH_BINARY)
                motion_mask = cv2.dilate(motion_mask, None, iterations=2)
                contours, _ = cv2.findContours(motion_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                for contour in contours:
                    if cv2.contourArea(contour) > 900:
                        motion_boxes.append(cv2.boundingRect(contour))
            previous_gray = gray_blur

            # Build the exact tracker-box list once. Ransom uses this same list that is
            # rendered as cyan Motion Tracker boxes, rather than raw image-difference
            # contours that may not be visible in the tracker.
            if modules.get("Motion Tracker", False):
                motion_tracker_boxes = list(match_tracks(motion_boxes))
            else:
                tracks.clear()
                motion_tracker_boxes = []

            # Ransom animation/challenge state machine. Motion is checked only while Blocka90 is shown.
            ransom_enabled = modules.get("Ransom Module", False) and modules.get("Motion Tracker", False)
            ransom_now = time.time()
            if ransom_enabled and powered and not ransom_failed and (not ransom_survived or ransom_phase == "success"):
                if ransom_phase == "idle" and ransom_now >= ransom_next_roll_time:
                    # One 1-in-5 roll every 10 seconds.
                    ransom_next_roll_time = ransom_now + 10.0
                    if random.randint(1, 1) == 1:
                        ransom_phase = "idle_warning"
                        ransom_phase_started = ransom_now
                        ransom_status_message = "A-90 WARNING - DO NOT MOVE"
                        ransom_coin_positions.clear()
                        log_event("Ransom appeared", "A-90 idle warning started")
                        # Start the preloaded sound immediately in the same update
                        # that makes the A-90 idle face appear (low-latency mixer).
                        if ransom_audio_channel is not None and sound_ransom_glitchy is not None:
                            ransom_audio_channel.stop()
                            ransom_audio_channel.set_volume(1.0)
                            ransom_audio_channel.play(sound_ransom_glitchy, loops=0, maxtime=0, fade_ms=0)
                        ransom_audio_r4nsom_due = None
                        ransom_audio_encounter_due = None
                        ransom_audio_encounter_played = False
                        trigger_alert("A-90 WARNING - DO NOT MOVE")
                elif ransom_phase == "idle_warning" and ransom_now - ransom_phase_started >= 0.4:
                    ransom_phase = "block"
                    ransom_phase_started = ransom_now
                    ransom_block_movement_detected = False
                    ransom_stop_active = True
                    ransom_status_message = "BLOCK A-90 - DO NOT MOVE"
                elif ransom_phase == "block":
                    # Watch the whole one-second Blocka90 window. Movement is only
                    # tagged here; no jumpscare starts until the full second is over.
                    if len(motion_tracker_boxes) > 0:
                        if not ransom_block_movement_detected:
                            log_event("Ransom movement tagged", f"{len(motion_tracker_boxes)} visible cyan tracker box(es)")
                        ransom_block_movement_detected = True
                    if ransom_now - ransom_phase_started >= 1.0:
                        ransom_stop_active = False
                        ransom_coin_positions.clear()
                        if ransom_block_movement_detected:
                            # Movement confirmed after the full Blocka90 cooldown.
                            ransom_phase = "move_jumpscare"
                            ransom_phase_started = ransom_now
                            ransom_status_message = "MOVEMENT DETECTED - A-90 ATTACK"
                            log_event("Ransom movement confirmed", "Movement detected during the one-second Blocka90 window")
                            # Start the movement soundtrack after the decision, then
                            # schedule R4NSOM 12 seconds later.
                            if ransom_audio_channel is not None:
                                ransom_audio_channel.stop()
                                if sound_ransom_start is not None:
                                    ransom_audio_channel.play(sound_ransom_start, loops=0, maxtime=0, fade_ms=0)
                            ransom_audio_r4nsom_due = ransom_now + 14.0
                            ransom_audio_encounter_due = None
                            ransom_audio_encounter_played = False
                            trigger_alert("A-90 MOVEMENT DETECTED")
                        else:
                            ransom_phase = "safe_flash"
                            ransom_phase_started = ransom_now
                            ransom_status_message = "A-90 LEFT - UNAFFECTED"
                            log_event("Ransom avoided", "No cyan Motion Tracker boxes during the one-second Blocka90 window")
                elif ransom_phase == "safe_flash" and ransom_now - ransom_phase_started >= 0.22:
                    # Stayed still: briefly show Thestareman3, then remove red static
                    # and end this encounter. Do NOT start downloading or coins.
                    ransom_phase = "idle"
                    ransom_phase_started = ransom_now
                    ransom_next_roll_time = ransom_now + 10.0
                    ransom_status_message = "A-90 LEFT - EVENT ENDED"
                    ransom_coin_positions.clear()
                elif ransom_phase == "move_jumpscare" and ransom_now - ransom_phase_started >= 1.0:
                    # Movement path: after the delayed one-second jumpscare, download.
                    ransom_phase = "download"
                    ransom_phase_started = ransom_now
                    ransom_download_progress = 0
                    ransom_status_message = "DOWNLOADING"
                elif ransom_phase == "download":
                    progress = min(1.0, (ransom_now - ransom_phase_started) / RANSOM_DOWNLOAD_DURATION)
                    ransom_download_progress = int(progress * RANSOM_DOWNLOAD_CHUNKS)
                    if progress >= 1.0:
                        ransom_phase = "collect"
                        ransom_phase_started = ransom_now
                        ransom_collect_started = ransom_now
                        ransom_next_coin_time = ransom_now + 0.15
                        ransom_status_message = "COLLECT 500 POINTS - 1:30"
                        log_event("Ransom collection started", "90-second timer started")
                elif ransom_phase == "success" and ransom_now - ransom_phase_started >= 1.5:
                    # Thank-you image has been shown; clear the images/red static and leave green static.
                    ransom_phase = "success_green"
                    ransom_phase_started = ransom_now
                    ransom_coin_positions.clear()
                elif ransom_phase == "collect":
                    elapsed = ransom_now - ransom_collect_started
                    if elapsed >= RANSOM_TIME_LIMIT:
                        ransom_failed = True
                        battery_level = max(0.0, battery_level - 60.0)  # Failure penalty: -60 battery points.
                        ransom_coin_positions.clear()
                        ransom_phase = "fail_jumpscare"
                        ransom_phase_started = ransom_now
                        ransom_status_message = "TIME EXPIRED"
                        if ransom_audio_channel is not None:
                            ransom_audio_channel.stop()
                            if sound_ransom_jumpscare2 is not None:
                                ransom_audio_channel.play(sound_ransom_jumpscare2)
                        ransom_audio_r4nsom_due = None
                        ransom_audio_encounter_due = None
                        ransom_audio_encounter_played = True
                        log_event("Ransom challenge failed", f"Timer expired at {ransom_coins_collected}/{RANSOM_GOAL} points")
                    elif ransom_now >= ransom_next_coin_time and len(ransom_coin_positions) < 12:
                        ransom_coin_id += 1
                        margin = 24
                        ransom_coin_positions.append((random.randint(margin, CAM_W - margin), random.randint(margin, CAM_H - margin), 12, ransom_coin_id))
                        ransom_next_coin_time = ransom_now + random.uniform(0.25, 0.6)
            elif not ransom_enabled or not powered:
                if ransom_phase in ("idle_warning", "block", "safe_flash", "download", "collect"):
                    ransom_phase = "idle"
                    ransom_stop_active = False
                    ransom_status_message = "RANSOM MODULE PAUSED"
                    ransom_coin_positions.clear()

            # Timed jumpscare/fade sequence after movement or timer failure.
            if ransom_phase == "fail_jumpscare" and ransom_now - ransom_phase_started >= 1.0:
                ransom_phase = "fail_stare2"
                ransom_phase_started = ransom_now
            elif ransom_phase == "fail_stare2" and ransom_now - ransom_phase_started >= 0.22:
                ransom_phase = "fail_static"
                ransom_phase_started = ransom_now
                ransom_fail_static_started = ransom_now
                ransom_fail_static_alpha = random.randint(179, 204)  # 0.2-0.3 transparency (70-80% visible)
            elif ransom_phase == "fail_static" and ransom_now - ransom_fail_static_started >= 180.0:
                # The red static has faded away after three minutes.
                ransom_phase = "idle"
                ransom_failed = False
                ransom_coins_collected = 0
                ransom_status_message = "RANSOM STATIC CLEARED"
                ransom_next_roll_time = ransom_now + 10.0
                log_event("Ransom static cleared", "Three-minute fade completed")

            # Ransom audio uses absolute deadlines from confirmed movement:
            # Ransom_start starts on confirmation, R4NSOM starts at +12 seconds,
            # and encounter starts +75 seconds after R4NSOM.
            # Winning clears both deadlines and stops the channel immediately.
            if ransom_phase in ("move_jumpscare", "download", "collect") and not ransom_survived and not ransom_failed:
                if (ransom_audio_r4nsom_due is not None and ransom_now >= ransom_audio_r4nsom_due):
                    r4nsom_scheduled_start = ransom_audio_r4nsom_due
                    if ransom_audio_channel is not None:
                        ransom_audio_channel.stop()
                        if sound_ransom_r4nsom is not None:
                            ransom_audio_channel.play(sound_ransom_r4nsom, loops=0, maxtime=0, fade_ms=0)
                    # Anchor the encounter deadline to the intended R4NSOM start time.
                    ransom_audio_encounter_due = r4nsom_scheduled_start + 600
                    ransom_audio_r4nsom_due = None
                if (ransom_audio_encounter_due is not None and ransom_now >= ransom_audio_encounter_due
                        and not ransom_audio_encounter_played):
                    if ransom_audio_channel is not None:
                        ransom_audio_channel.stop()
                        if sound_ransom_encounter is not None:
                            ransom_audio_channel.play(sound_ransom_encounter, loops=-1, maxtime=0, fade_ms=0)
                    ransom_audio_encounter_played = True
            elif ransom_phase == "success" and ransom_audio_channel is not None:
                # The success event handler already starts this immediately; this is a fallback.
                if sound_ransom_success is not None and not ransom_audio_encounter_played:
                    ransom_audio_channel.stop()
                    ransom_audio_channel.play(sound_ransom_success, loops=0, maxtime=0, fade_ms=0)
                    ransom_audio_r4nsom_due = None
                    ransom_audio_encounter_due = None
                    ransom_audio_encounter_played = True
            elif ransom_phase == "fail_jumpscare" and ransom_audio_channel is not None:
                # The failure event handler already starts this immediately; this is a fallback.
                if sound_ransom_jumpscare2 is not None and not ransom_audio_encounter_played:
                    ransom_audio_channel.stop()
                    ransom_audio_channel.play(sound_ransom_jumpscare2, loops=0, maxtime=0, fade_ms=0)
                    ransom_audio_r4nsom_due = None
                    ransom_audio_encounter_due = None
                    ransom_audio_encounter_played = True

            # Visual filters. Thermal Vision is a false-color effect, not a real heat sensor.
            if modules["Nightvision"]:
                green_frame = np.zeros_like(frame)
                green_frame[:, :, 1] = cv2.equalizeHist(gray)
                frame = cv2.addWeighted(frame, 0.12, green_frame, 0.95, 0)
            if modules.get("Space Module", False):
                # Green, clearer vision; Q swaps to the stronger night-vision look.
                frame = apply_space_nightvision(frame) if space_nv_active else apply_space_base(frame)
            if modules["Thermal Vision"]:
                thermal_palettes = [cv2.COLORMAP_INFERNO, cv2.COLORMAP_JET, cv2.COLORMAP_TURBO, cv2.COLORMAP_MAGMA]
                thermal_base = cv2.applyColorMap(cv2.equalizeHist(gray), thermal_palettes[thermal_palette_index % len(thermal_palettes)])
                frame = cv2.addWeighted(frame, max(0.0, 1.0 - thermal_intensity), thermal_base, min(1.0, thermal_intensity), 0)
                cv2.putText(frame, f"THERMAL PALETTE {thermal_palette_index + 1} INTENSITY {thermal_intensity:.1f}", (12, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (255, 255, 255), 1)
            if modules["Edge Detection"]:
                edges = cv2.Canny(gray, 65, 145)
                edge_bgr = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)
                frame = cv2.addWeighted(frame, 0.45, edge_bgr, 0.9, 0)
            if modules.get("Light Analyzer", False):
                brightness = float(np.mean(gray))
                cv2.putText(frame, f"LIGHT LEVEL {brightness:05.1f}/255", (12, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (100, 255, 150), 2)
            if modules.get("Coordinate Grid", False):
                for gx in range(1, 8):
                    x_grid = gx * CAM_W // 8
                    cv2.line(frame, (x_grid, 0), (x_grid, CAM_H), (55, 120, 75), 1)
                    cv2.putText(frame, str(x_grid), (x_grid + 2, 14), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (100, 200, 120), 1)
                for gy in range(1, 5):
                    y_grid = gy * CAM_H // 5
                    cv2.line(frame, (0, y_grid), (CAM_W, y_grid), (55, 120, 75), 1)
                    cv2.putText(frame, str(y_grid), (2, y_grid - 3), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (100, 200, 120), 1)
            if modules.get("Detail Enhancer", False):
                blurred_detail = cv2.GaussianBlur(frame, (0, 0), 1.2)
                frame = cv2.addWeighted(frame, 1.35, blurred_detail, -0.35, 0)

            # Human detection is refreshed a few times per second rather than every frame,
            # reducing CPU spikes while keeping boxes responsive.
            if modules["Human Detector"]:
                now_detect = time.time()
                if now_detect - last_human_run >= 0.22 * overload_factor:
                    refreshed_humans = []
                    if face_detector is not None:
                        faces = face_detector.detectMultiScale(
                            gray, scaleFactor=1.12, minNeighbors=5, minSize=(28, 28)
                        )
                        for (x, y, w, h) in faces:
                            refreshed_humans.append((x, y, w, h, "FACE"))
                    try:
                        # HOG is expensive; run on a smaller image and scale boxes back up.
                        small_gray = cv2.resize(gray, (CAM_W // 2, CAM_H // 2), interpolation=cv2.INTER_AREA)
                        bodies, _ = hog_detector.detectMultiScale(
                            small_gray, winStride=(8, 8), padding=(8, 8), scale=1.05
                        )
                        for (x, y, w, h) in bodies:
                            refreshed_humans.append((x * 2, y * 2, w * 2, h * 2, "BODY"))
                    except cv2.error:
                        pass
                    # Skin-region heuristic uses the half-size frame to lower processing cost.
                    small_frame = cv2.resize(frame, (CAM_W // 2, CAM_H // 2), interpolation=cv2.INTER_AREA)
                    for (x, y, w, h) in detect_skin_regions(small_frame):
                        refreshed_humans.append((x * 2, y * 2, w * 2, h * 2, "SKIN REGION"))
                    human_boxes_cache = refreshed_humans
                    last_human_run = now_detect
                human_boxes = list(human_boxes_cache)
            else:
                human_boxes_cache = []

            # Motion tracker draws the same boxes that the Ransom check reads.
            # OpenCV's BGR (255, 220, 40) displays as cyan/yellow-blue on screen.
            if modules["Motion Tracker"]:
                for track_id, (x, y, w, h) in motion_tracker_boxes:
                    cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 220, 40), 2)
                    cv2.putText(frame, f"MOTION #{track_id}", (x, max(15, y - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 220, 40), 2)

            # Human detections use thick white boxes.
            for x, y, w, h, label in human_boxes:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 255, 255), 3)
                cv2.putText(frame, label, (x, max(18, y - 7)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2)

            # Threat detector: flags movement inside the right-side restricted zone
            # and selected YOLO object classes. It does not infer intent.
            zone_x1, zone_y1 = int(CAM_W * 0.68), int(CAM_H * 0.20)
            zone_x2, zone_y2 = CAM_W - 8, int(CAM_H * 0.92)
            if modules["Threat Detector"]:
                cv2.rectangle(frame, (zone_x1, zone_y1), (zone_x2, zone_y2), (0, 0, 255), 2)
                cv2.putText(frame, "RESTRICTED ZONE", (zone_x1 + 5, zone_y1 - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
                for x, y, w, h in motion_boxes:
                    cx, cy = x + w // 2, y + h // 2
                    if zone_x1 <= cx <= zone_x2 and zone_y1 <= cy <= zone_y2:
                        threat_triggered = True
                        threat_reasons.append("Movement in restricted zone")
                if model is not None:
                    # YOLO is the heaviest module, so run inference every 0.65s and
                    # reuse its last boxes between runs instead of blocking every frame.
                    now_yolo = time.time()
                    if now_yolo - last_yolo_run >= 0.65 * overload_factor:
                        refreshed_yolo = []
                        try:
                            results = model.predict(frame, verbose=False, conf=0.45, imgsz=416)
                            for result in results:
                                names = result.names
                                for box in result.boxes:
                                    cls_id = int(box.cls[0])
                                    label = str(names.get(cls_id, cls_id)).lower()
                                    if label in {"backpack", "handbag", "suitcase"}:
                                        x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                                        refreshed_yolo.append((x1, y1, x2, y2, label))
                            yolo_boxes_cache = refreshed_yolo
                        except Exception as exc:
                            print(f"[NVCS] YOLO inference issue: {exc}")
                            yolo_boxes_cache = []
                        last_yolo_run = now_yolo
                    for x1, y1, x2, y2, label in yolo_boxes_cache:
                        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 3)
                        cv2.putText(frame, f"WATCHLIST: {label}", (x1, max(18, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 255), 2)
                        threat_triggered = True
                        threat_reasons.append(f"Detected object: {label}")
                if threat_triggered:
                    trigger_alert(", ".join(sorted(set(threat_reasons))))
                    # Red border is a visual alert only.
                    cv2.rectangle(frame, (2, 2), (CAM_W - 3, CAM_H - 3), (0, 0, 255), 7)

            # Object Classification: cached YOLO labels, refreshed less often under load.
            if modules.get("Object Classification", False) and model is not None:
                now_classify = time.time()
                if now_classify - last_classification_run >= 0.90 * overload_factor:
                    refreshed_classification = []
                    try:
                        results = model.predict(frame, verbose=False, conf=0.40, imgsz=416)
                        for result in results:
                            names = result.names
                            for box in result.boxes:
                                x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                                cls_id = int(box.cls[0])
                                label = str(names.get(cls_id, cls_id))
                                confidence = float(box.conf[0])
                                refreshed_classification.append((x1, y1, x2, y2, label, confidence))
                        classification_boxes_cache = refreshed_classification[:20]
                    except Exception as exc:
                        print(f"[NVCS] Classification inference issue: {exc}")
                        classification_boxes_cache = []
                    last_classification_run = now_classify
                for x1, y1, x2, y2, label, confidence in classification_boxes_cache:
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 180, 40), 2)
                    cv2.putText(frame, f"{label} {confidence:.0%}", (x1, max(16, y1 - 5)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 180, 40), 2)
            elif not modules.get("Object Classification", False):
                classification_boxes_cache = []

            # Motion Vector estimates each region's direction by matching its center to the prior frame.
            if modules.get("Motion Vector", False):
                current_centers = {}
                for index, (mx, my, mw, mh) in enumerate(motion_boxes):
                    cx, cy = mx + mw // 2, my + mh // 2
                    current_centers[index] = (cx, cy)
                    if index in motion_vector_previous:
                        px, py = motion_vector_previous[index]
                        if math.hypot(cx - px, cy - py) > 2:
                            cv2.arrowedLine(frame, (px, py), (cx, cy), (255, 180, 40), 2, tipLength=0.25)
                motion_vector_previous = current_centers
            else:
                motion_vector_previous = {}

            # Proximity Alert is based on apparent image size, not actual distance.
            if modules.get("Proximity Alert", False):
                proximity_boxes = [(x, y, w, h) for x, y, w, h, _label in human_boxes]
                if not proximity_boxes:
                    proximity_boxes = motion_boxes
                largest_ratio = max(((w * h) / float(CAM_W * CAM_H) for x, y, w, h in proximity_boxes), default=0.0)
                if largest_ratio > 0.18:
                    cv2.putText(frame, "PROXIMITY WARNING: LARGE IMAGE TARGET", (12, 45), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (0, 0, 255), 2)

            # Interference Detector checks sudden brightness change and blur.
            if modules.get("Interference Detector", False):
                brightness_now = float(np.mean(gray))
                blur_score = float(cv2.Laplacian(gray, cv2.CV_64F).var())
                if previous_gray is not None and (blur_score < 18 or abs(brightness_now - float(np.mean(previous_gray))) > 48):
                    cv2.putText(frame, "SIGNAL INTERFERENCE", (12, 64), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 180, 255), 2)

            # Track History keeps a short history of moving-region centers.
            if modules.get("Track History", False):
                history_now = time.time()
                for hx, hy, hw, hh in motion_boxes:
                    track_history_points.append((hx + hw // 2, hy + hh // 2, history_now))
                track_history_points[:] = [point for point in track_history_points if history_now - point[2] < 2.0]
                for index, (hx, hy, ht) in enumerate(track_history_points):
                    radius = max(1, int(6 * (1.0 - (history_now - ht) / 2.0)))
                    cv2.circle(frame, (hx, hy), radius, (180, 80, 255), 1)
            else:
                track_history_points.clear()

            # Session Timeline event list is rendered in the HUD/menu; motion alerts log elsewhere.

            # Radar display: plots detected motion centroids around a simple radar circle.
            if modules["Radar Scanner"]:
                center = (CAM_W - 75, 75)
                radius = 48
                cv2.circle(frame, center, radius, (0, 255, 120), 1)
                cv2.line(frame, (center[0] - radius, center[1]), (center[0] + radius, center[1]), (0, 255, 120), 1)
                cv2.line(frame, (center[0], center[1] - radius), (center[0], center[1] + radius), (0, 255, 120), 1)
                for x, y, w, h in motion_boxes:
                    px = int(center[0] + ((x + w / 2) / CAM_W - 0.5) * radius * 1.7)
                    py = int(center[1] + ((y + h / 2) / CAM_H - 0.5) * radius * 1.7)
                    cv2.circle(frame, (px, py), 3, (0, 255, 120), -1)

            # Event Recorder records motion/threat events while enabled.
            if modules["Event Recorder"]:
                if threat_triggered:
                    log_event("Threat recorded", ", ".join(sorted(set(threat_reasons))))
                    if time.time() - last_auto_snapshot_time > 5.0:
                        os.makedirs(os.path.join(BASE_DIR, "snapshots"), exist_ok=True)
                        auto_path = os.path.join(BASE_DIR, "snapshots", f"nvcs_alert_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
                        cv2.imwrite(auto_path, frame)
                        last_auto_snapshot_time = time.time()
                        log_event("Alert snapshot saved", auto_path)
                elif motion_boxes:
                    # Limit repeated motion log spam to one event per second.
                    if time.time() - last_static_time > 1.0:
                        log_event("Motion detected", f"{len(motion_boxes)} region(s)")
                        last_static_time = time.time()

            # Target Lock chooses the detection nearest the frame center and keeps it highlighted.
            target_candidates = [(x, y, w, h, label) for x, y, w, h, label in human_boxes]
            if modules.get("Target Lock", False):
                if not target_candidates:
                    target_candidates = [(x, y, w, h, "MOTION") for x, y, w, h in motion_boxes]
                if target_candidates:
                    tx, ty, tw, th, tlabel = min(target_candidates, key=lambda b: math.hypot((b[0] + b[2] / 2) - CAM_W / 2, (b[1] + b[3] / 2) - CAM_H / 2))
                    cv2.rectangle(frame, (tx - 5, ty - 5), (tx + tw + 5, ty + th + 5), (0, 255, 255), 3)
                    cv2.putText(frame, f"LOCK: {tlabel}", (tx, max(18, ty - 12)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255), 2)
                else:
                    cv2.putText(frame, "TARGET LOCK: SEARCHING", (15, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255), 2)

            # Range Finder estimates relative distance from box size; it is not calibrated real-world distance.
            if modules.get("Range Finder", False):
                range_candidates = [(x, y, w, h, label) for x, y, w, h, label in human_boxes]
                if not range_candidates and motion_boxes:
                    range_candidates = [(x, y, w, h, "MOTION") for x, y, w, h in motion_boxes]
                for rx, ry, rw, rh, rlabel in range_candidates[:4]:
                    area_ratio = (rw * rh) / float(CAM_W * CAM_H)
                    range_label = "NEAR" if area_ratio > 0.12 else ("MEDIUM" if area_ratio > 0.035 else "FAR")
                    cv2.putText(frame, f"{range_label} {rlabel}", (rx, min(CAM_H - 8, ry + rh + 18)), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (255, 210, 65), 2)

            # Signal Scanner shows a sweeping line and reacts to motion activity.
            if modules.get("Signal Scanner", False):
                signal_sweep_x = (signal_sweep_x + 9) % CAM_W
                signal_strength = min(100, len(motion_boxes) * 18 + (12 if human_boxes else 0))
                cv2.line(frame, (signal_sweep_x, 0), (signal_sweep_x, CAM_H), (0, 255, 100), 1)
                cv2.putText(frame, f"SIGNAL {signal_strength:02d}%", (12, CAM_H - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 100), 2)

            # Echo Scan draws a moving scan line with expanding ring-like arcs.
            if modules.get("Echo Scan", False):
                echo_y = int((time.time() * 115) % CAM_H)
                cv2.line(frame, (0, echo_y), (CAM_W, echo_y), (80, 255, 170), 2)
                cv2.circle(frame, (CAM_W // 2, CAM_H // 2), int((time.time() * 75) % max(1, min(CAM_W, CAM_H) // 2)), (80, 255, 170), 1)
                cv2.putText(frame, "ECHO PULSE", (12, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (80, 255, 170), 2)

            # Ghost Trail leaves short-lived trails at moving-region centers.
            if modules.get("Ghost Trail", False):
                now_trail = time.time()
                for mx, my, mw, mh in motion_boxes:
                    motion_trails.append((mx + mw // 2, my + mh // 2, now_trail))
                motion_trails[:] = [t for t in motion_trails if now_trail - t[2] < 1.25]
                for gx, gy, gt in motion_trails:
                    alpha_radius = max(2, int(8 * (1.25 - (now_trail - gt))))
                    cv2.circle(frame, (gx, gy), alpha_radius, (255, 100, 255), 1)
            else:
                motion_trails.clear()

            # LIDAR Scan is a simulated visual sweep using image edges and motion regions.
            # A normal webcam has no real depth sensor, so this is not true distance mapping.
            if modules.get("LIDAR Scan", False):
                lidar_sweep_y = (lidar_sweep_y + 5) % CAM_H
                lidar_edges = cv2.Canny(gray, 85, 170)
                # Draw only sampled edge points near the scan line to limit per-frame overhead.
                y_start, y_end = max(0, lidar_sweep_y - 3), min(CAM_H, lidar_sweep_y + 4)
                points_y, points_x = np.where(lidar_edges[y_start:y_end, :] > 0)
                if len(points_x) > 550:
                    sample_indices = np.linspace(0, len(points_x) - 1, 550).astype(int)
                    points_x, points_y = points_x[sample_indices], points_y[sample_indices]
                for px, py_local in zip(points_x, points_y):
                    cv2.circle(frame, (int(px), int(y_start + py_local)), 1, (0, 255, 90), -1)
                cv2.line(frame, (0, lidar_sweep_y), (CAM_W - 1, lidar_sweep_y), (0, 255, 90), 2)
                cv2.putText(frame, "LIDAR SCAN / SIMULATED", (12, CAM_H - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (0, 255, 90), 2)

            # LIDAR 2.0: accumulate sampled edge points into a pseudo point cloud.
            # This is an image-derived visualization, not real depth sensing.
            if modules.get("LIDAR 2.0 — Point Cloud", False):
                cloud_edges = cv2.Canny(gray, 75, 155)
                py_cloud, px_cloud = np.where(cloud_edges > 0)
                if len(px_cloud) > 180:
                    indices = np.linspace(0, len(px_cloud) - 1, 180).astype(int)
                    px_cloud, py_cloud = px_cloud[indices], py_cloud[indices]
                t_cloud = time.time()
                for px, py in zip(px_cloud, py_cloud):
                    point_cloud.append((int(px), int(py), t_cloud))
                point_cloud[:] = [p for p in point_cloud if t_cloud - p[2] < 2.5]
                if len(point_cloud) > 3000:
                    point_cloud = point_cloud[-3000:]
                for px, py, pt in point_cloud[::3]:
                    fade = max(0.15, 1.0 - (t_cloud - pt) / 2.5)
                    cv2.circle(frame, (px, py), 1, (0, int(180 + 75 * fade), 60), -1)
                cv2.putText(frame, f"POINT CLOUD {len(point_cloud)} PTS", (12, 42), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 90), 1)

            # Surface Reconstruction: approximate a wireframe from edge contours.
            if modules.get("Surface Reconstruction", False):
                surface_edges = cv2.Canny(gray, 70, 150)
                contours_surface, _ = cv2.findContours(surface_edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
                for contour in contours_surface[:100]:
                    if cv2.arcLength(contour, False) > 40:
                        approx = cv2.approxPolyDP(contour, 3.0, False)
                        cv2.polylines(frame, [approx], False, (255, 190, 40), 1)
                cv2.putText(frame, "SURFACE MAP / 2D APPROXIMATION", (12, 42), cv2.FONT_HERSHEY_SIMPLEX, 0.43, (255, 190, 40), 1)

            # Multi-Pass Scan: gradually accumulate sampled edges until one pass completes.
            if modules.get("Multi-Pass Scan", False):
                multi_edges = cv2.Canny(gray, 85, 170)
                multi_y, multi_x = np.where(multi_edges > 0)
                if len(multi_x) > 120:
                    sample_ids = np.linspace(0, len(multi_x) - 1, 120).astype(int)
                    multi_x, multi_y = multi_x[sample_ids], multi_y[sample_ids]
                for px, py in zip(multi_x, multi_y):
                    multipass_points.append((int(px), int(py)))
                if len(multipass_points) > 5000:
                    multipass_points = multipass_points[-5000:]
                multipass_progress = min(100, multipass_progress + 0.35)
                for px, py in multipass_points[::5]:
                    cv2.circle(frame, (px, py), 1, (80, 255, 150), -1)
                cv2.putText(frame, f"MULTI-PASS {multipass_progress:05.1f}% (R RESET)", (12, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (80, 255, 150), 1)
                if multipass_progress >= 100:
                    cv2.putText(frame, "SCAN COMPLETE", (CAM_W - 190, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (80, 255, 150), 2)

            # Pixel Inspector reports the source pixel under the cursor.
            if modules.get("Pixel Inspector", False):
                mouse_x, mouse_y = pygame.mouse.get_pos()
                if CAM_X <= mouse_x < CAM_X + CAM_W and CAM_Y <= mouse_y < CAM_Y + CAM_H:
                    px, py = mouse_x - CAM_X, mouse_y - CAM_Y
                    bgr_sample = original_frame[py, px]
                    b, g, r = [int(v) for v in bgr_sample]
                    cv2.drawMarker(frame, (px, py), (255, 255, 255), cv2.MARKER_CROSS, 14, 1)
                    cv2.putText(frame, f"PIXEL ({px},{py}) RGB({r},{g},{b}) Y={int(gray[py,px])}", (12, CAM_H - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (255, 255, 255), 1)

            # Pixel Counter counts pixels close to the sampled color.
            if modules.get("Pixel Counter", False):
                if pixel_counter_color is None:
                    cv2.putText(frame, "PIXEL COUNTER: CLICK IMAGE TO SAMPLE COLOR", (12, 42), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (80, 255, 150), 1)
                else:
                    rgb_pixels = cv2.cvtColor(original_frame, cv2.COLOR_BGR2RGB).astype(np.int16)
                    target_color = np.array(pixel_counter_color, dtype=np.int16)
                    tolerance = 28
                    similar = np.all(np.abs(rgb_pixels - target_color) <= tolerance, axis=2)
                    pixel_counter_count = int(np.count_nonzero(similar))
                    cv2.putText(frame, f"COLOR {pixel_counter_color} COUNT {pixel_counter_count}", (12, 42), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (80, 255, 150), 1)

            # Object Ruler: two mouse clicks measure pixel distance.
            if modules.get("Object Ruler", False):
                if len(ruler_points) >= 1:
                    cv2.circle(frame, ruler_points[0], 5, (0, 255, 255), 2)
                if len(ruler_points) >= 2:
                    p1, p2 = ruler_points[:2]
                    cv2.line(frame, p1, p2, (0, 255, 255), 2)
                    cv2.circle(frame, p2, 5, (0, 255, 255), 2)
                    distance_pixels = math.hypot(p2[0] - p1[0], p2[1] - p1[1])
                    cv2.putText(frame, f"RULER: {distance_pixels:.1f} PIXELS (C CLEAR)", (12, 42), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1)
                else:
                    cv2.putText(frame, "RULER: CLICK TWO POINTS (C CLEAR)", (12, 42), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 255, 255), 1)

            # Resolution Destroyer intentionally pixelates the camera feed.
            if modules.get("Resolution Destroyer", False):
                small_w = max(1, CAM_W // pixel_block_size)
                small_h = max(1, CAM_H // pixel_block_size)
                tiny = cv2.resize(frame, (small_w, small_h), interpolation=cv2.INTER_AREA)
                frame = cv2.resize(tiny, (CAM_W, CAM_H), interpolation=cv2.INTER_NEAREST)
                cv2.putText(frame, f"PIXELATION {pixel_block_size}px ([ / ] ADJUST)", (12, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 120), 1)

            # Binary Vision turns a downsampled live image into a compact 0/1 display.
            if modules.get("Binary Vision", False):
                binary_small = cv2.resize(gray, (64, 20), interpolation=cv2.INTER_AREA)
                _, binary_small = cv2.threshold(binary_small, 128, 255, cv2.THRESH_BINARY)
                overlay = frame.copy()
                cv2.rectangle(overlay, (CAM_W - 270, 8), (CAM_W - 8, 120), (0, 12, 4), -1)
                frame = cv2.addWeighted(overlay, 0.82, frame, 0.18, 0)
                for by in range(20):
                    line_bits = "".join("1" if v > 0 else "0" for v in binary_small[by, ::2])
                    cv2.putText(frame, line_bits, (CAM_W - 255, 17 + by * 5), cv2.FONT_HERSHEY_PLAIN, 0.32, (80, 255, 130), 1)

            # Brightness Seismograph stores recent average brightness and draws a mini graph.
            if modules.get("Brightness Seismograph", False):
                brightness_history.append(float(np.mean(gray)))
                brightness_history[:] = brightness_history[-100:]
                graph_x, graph_y, graph_w, graph_h = 12, 82, 180, 50
                cv2.rectangle(frame, (graph_x, graph_y), (graph_x + graph_w, graph_y + graph_h), (0, 45, 20), 1)
                if len(brightness_history) > 1:
                    graph_points = []
                    for i, val in enumerate(brightness_history):
                        gx = graph_x + int(i * (graph_w - 2) / max(1, len(brightness_history) - 1)) + 1
                        gy = graph_y + graph_h - 2 - int((val / 255.0) * (graph_h - 4))
                        graph_points.append((gx, gy))
                    cv2.polylines(frame, [np.array(graph_points, dtype=np.int32)], False, (80, 255, 130), 1)
                cv2.putText(frame, f"BRIGHTNESS {brightness_history[-1]:.1f}", (graph_x, graph_y - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (80, 255, 130), 1)

            # Quantum Scanner applies a deliberately fictional, animated tile displacement.
            if modules.get("Quantum Scanner", False):
                quantum_frame_counter += 1
                if quantum_frame_counter % 3 == 0:
                    tile_h, tile_w = 24, 32
                    quantum_frame = frame.copy()
                    for tile_y in range(0, CAM_H - tile_h, tile_h * 3):
                        for tile_x in range(0, CAM_W - tile_w, tile_w * 3):
                            dx = random.randint(-5, 5)
                            sx1, sx2 = max(0, tile_x + dx), min(CAM_W, tile_x + dx + tile_w)
                            if sx2 > sx1:
                                quantum_frame[tile_y:tile_y + tile_h, tile_x:tile_x + (sx2 - sx1)] = frame[tile_y:tile_y + tile_h, sx1:sx2]
                    frame = quantum_frame
                    cv2.putText(frame, "QUANTUM PHASE SHIFT / SIMULATED", (12, CAM_H - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.43, (255, 80, 255), 1)

            # Space Module overlays: R = movement + LIDAR-style cloud, Q = objects + distance.
            if modules.get("Space Module", False):
                if space_scan_active:
                    draw_space_scan(frame, gray, motion_boxes)
                if space_nv_active:
                    draw_space_objects(frame, original_frame, motion_boxes)
                cv2.putText(frame, f"SPACE  [R] SCAN:{'ON' if space_scan_active else 'OFF'}  [Q] NIGHT:{'ON' if space_nv_active else 'OFF'}",
                            (CAM_W - 330, CAM_H - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (120, 255, 160), 1)

            # Anomaly Module marks motion regions in magenta during the hunt.
            if modules.get("Anomaly Module", False) and active_minigame == "anomaly":
                for ax, ay, aw, ah in motion_boxes:
                    cv2.rectangle(frame, (ax, ay), (ax + aw, ay + ah), (255, 0, 220), 2)
                    cv2.putText(frame, "ANOMALY?", (ax, max(15, ay - 5)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 0, 220), 1)
                cv2.putText(frame, "A: ANOMALY HUNT - CLICK MAGENTA REGION", (12, CAM_H - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (255, 0, 220), 1)

            # Split View compares the original camera feed with the processed feed.
            if modules.get("Split View", False):
                original_half = cv2.resize(original_frame, (CAM_W // 2, CAM_H), interpolation=cv2.INTER_AREA)
                processed_half = cv2.resize(frame, (CAM_W // 2, CAM_H), interpolation=cv2.INTER_AREA)
                cv2.putText(original_half, "ORIGINAL", (10, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (80, 255, 130), 2)
                cv2.putText(processed_half, "PROCESSED", (10, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (80, 255, 130), 2)
                frame = np.hstack((original_half, processed_half))

            # Error Module is applied last so the corruption sits over everything else.
            if modules.get("Error Module", False):
                frame = apply_error_effect(frame)

            # Keep output frame in RGB for conversion to Pygame.
            frame_to_show = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            last_display_frame_rgb = frame_to_show.copy()
            frame_process_ms = (time.perf_counter() - frame_start_time) * 1000.0
        else:
            draw_text(screen, "CAMERA SIGNAL LOST", CAM_X + 250, CAM_Y + 160, RED)
    else:
        # A powered-off scanner is completely black; no idle static image/noise.
        pygame.draw.rect(screen, (0, 0, 0), (CAM_X, CAM_Y, CAM_W, CAM_H))
        if battery_level <= 0:
            off_message = "BATTERY DEPLETED - RECHARGING"
            draw_text(screen, off_message, CAM_X + 245, CAM_Y + CAM_H // 2, (100, 120, 105), SMALL)
        else:
            draw_text(screen, "SCANNER OFF - PRESS F TO POWER ON", CAM_X + 230, CAM_Y + CAM_H // 2, (75, 95, 82), SMALL)

    if powered and freeze_active and frozen_frame_rgb is not None:
        frame_to_show = frozen_frame_rgb
    if frame_to_show is not None:
        surface = pygame.surfarray.make_surface(np.transpose(frame_to_show, (1, 0, 2)))
        screen.blit(surface, (CAM_X, CAM_Y))

    # Subtle animated green static while the scanner is running. Hide it during
    # the active Ransom sequence so it cannot tint/cover the red A-90 static.
    now = time.time()
    ransom_red_stage_active = (
        powered
        and modules.get("Ransom Module", False)
        and modules.get("Motion Tracker", False)
        and ransom_phase in (
            "idle_warning", "block", "safe_flash", "move_jumpscare", "move_stare2",
            "download", "collect", "success", "success_green", "fail_jumpscare", "fail_stare2", "fail_static"
        )
    )
    if powered:
        if scanner_static_surface is None or now - last_noise_refresh >= 0.09:
            static_frame_index = (static_frame_index + 1) % len(STATIC_FRAMES)
            scanner_static_surface = STATIC_FRAMES[static_frame_index]
            last_noise_refresh = now
        if not ransom_red_stage_active:
            if modules.get("Space Module", False):
                # Space Module: much less static for a clearer picture.
                scanner_static_surface.set_alpha(random.randint(3, 12))
            else:
                # About 60%-90% transparent (10%-40% visible opacity).
                scanner_static_surface.set_alpha(random.randint(26, 102))
            screen.blit(scanner_static_surface, (CAM_X, CAM_Y))

    # Startup sequence: brief black pause, then strong green static that fades
    # away over one second to reveal the live camera feed underneath.
    if POWER_STATIC_ACTIVE and POWER_STATIC_START is not None:
        if now < POWER_STATIC_START:
            # The camera is still warming up; hide the feed for this short pause.
            pygame.draw.rect(screen, (0, 0, 0), (CAM_X, CAM_Y, CAM_W, CAM_H))
        else:
            elapsed = now - POWER_STATIC_START
            if elapsed >= POWER_STATIC_DURATION:
                POWER_STATIC_ACTIVE = False
                POWER_STATIC_START = None
                power_static_surface = None
            elif power_static_surface is not None:
                fade = 1.0 - (elapsed / POWER_STATIC_DURATION)
                # Start bright green, then smoothly fade to transparent.
                power_static_surface.set_alpha(int(235 * fade))
                screen.blit(power_static_surface, (CAM_X, CAM_Y))

    # Ransom visuals: red static, A-90 image sequence, download bar, and collection timer.
    ransom_visual_enabled = powered and modules.get("Ransom Module", False) and modules.get("Motion Tracker", False)
    ransom_failure_visual = powered and ransom_phase in ("fail_jumpscare", "fail_stare2", "fail_static", "move_jumpscare", "move_stare2")
    if ransom_visual_enabled or ransom_failure_visual:
        ransom_now_draw = time.time()
        # Red static accompanies every stage, then fades during the three-minute failure cooldown.
        ransom_image_phases = ("idle_warning", "block", "safe_flash", "move_jumpscare", "move_stare2", "download", "collect", "success", "fail_jumpscare", "fail_stare2", "fail_static")
        if ransom_phase == "success_green":
            # Successful completion swaps to green static only; no character image or red static.
            green_surface = STATIC_FRAMES[static_frame_index % len(STATIC_FRAMES)].copy()
            green_surface.set_alpha(90)
            screen.blit(green_surface, (CAM_X, CAM_Y))
        elif ransom_phase in ransom_image_phases:
            if ransom_now_draw - ransom_red_last_refresh >= 0.08:
                ransom_red_frame_index = (ransom_red_frame_index + 1) % len(RANSOM_RED_FRAMES)
                ransom_red_last_refresh = ransom_now_draw
            red_surface = RANSOM_RED_FRAMES[ransom_red_frame_index]
            if ransom_phase == "fail_static":
                fade_ratio = max(0.0, 1.0 - (ransom_now_draw - ransom_fail_static_started) / 180.0)
                if ransom_fail_static_alpha is None:
                    ransom_fail_static_alpha = random.randint(179, 204)  # 0.2-0.3 transparency (70-80% visible)
                red_alpha = int(ransom_fail_static_alpha * fade_ratio)
            elif ransom_phase == "collect":
                # During coin collection, red static is randomly 0.6-0.9 transparent.
                if ransom_red_alpha_until < ransom_now_draw:
                    ransom_red_alpha = random.randint(26, 102)
                    ransom_red_alpha_until = ransom_now_draw + random.uniform(0.15, 0.45)
                red_alpha = ransom_red_alpha
            else:
                # A-90 appearances and the download stage use fully opaque red static.
                red_alpha = 255
            red_surface.set_alpha(red_alpha)
            screen.blit(red_surface, (CAM_X, CAM_Y))

        image_key = None
        if ransom_phase == "idle_warning": image_key = "idle"
        elif ransom_phase in ("block",): image_key = "block"
        elif ransom_phase == "safe_flash": image_key = "safe_flash"
        elif ransom_phase in ("fail_jumpscare", "move_jumpscare"): image_key = "jumpscare"
        elif ransom_phase in ("fail_stare2", "move_stare2"): image_key = "stare2"
        elif ransom_phase == "success": image_key = "thanks"
        if image_key and RANSOM_IMAGES.get(image_key) is not None:
            image_surface = RANSOM_IMAGES[image_key]
            if image_key == "idle":
                image_size = (100, 100)
            elif image_key in ("jumpscare", "stare2"):
                image_size = (300, 300)  # larger faces, still contained inside the camera view
            elif image_key == "thanks":
                image_size = (440, 180)   # wide, computer-window-like thank-you panel
            else:
                image_size = (180, 180)
            if image_surface.get_size() != image_size:
                image_surface = pygame.transform.smoothscale(image_surface, image_size)
            image_x = CAM_X + (CAM_W - image_size[0]) // 2
            image_y = CAM_Y + (CAM_H - image_size[1]) // 2
            screen.blit(image_surface, (image_x, image_y))
        elif image_key:
            # Keep the sequence usable if a named art file has not been copied into assets/Image/Ransom yet.
            fallback = {"idle": "A-90 WARNING - DO NOT MOVE", "block": "STOP", "safe_flash": "A-90 LEFT", "jumpscare": "A-90", "stare2": "RANSOM", "thanks": "THANK YOU"}.get(image_key, "RANSOM")
            draw_text(screen, fallback, CAM_X + CAM_W // 2 - 75, CAM_Y + CAM_H // 2 - 12, WHITE, TITLE)

        if ransom_phase == "download":
            draw_text(screen, "Downloading :", CAM_X + CAM_W // 2 - 88, CAM_Y + CAM_H // 2 - 65, WHITE, TITLE)
            bar_w, bar_h = 470, 42
            bar_x = CAM_X + (CAM_W - bar_w) // 2
            bar_y = CAM_Y + CAM_H // 2 - 5
            pygame.draw.rect(screen, (18, 18, 18), (bar_x, bar_y, bar_w, bar_h))
            pygame.draw.rect(screen, (70, 70, 70), (bar_x + 5, bar_y + 5, bar_w - 10, bar_h - 10))
            pygame.draw.rect(screen, WHITE, (bar_x, bar_y, bar_w, bar_h), 3)
            inner_pad, gap = 5, 3
            inner_x, inner_y = bar_x + inner_pad, bar_y + inner_pad
            inner_w, inner_h = bar_w - inner_pad * 2, bar_h - inner_pad * 2
            chunk_w = (inner_w - gap * (RANSOM_DOWNLOAD_CHUNKS - 1)) / RANSOM_DOWNLOAD_CHUNKS
            for chunk_index in range(ransom_download_progress):
                chunk_x = int(inner_x + chunk_index * (chunk_w + gap))
                pygame.draw.rect(screen, WHITE, (chunk_x, inner_y, max(1, int(chunk_w)), inner_h))

        elif ransom_phase == "collect":
            elapsed = max(0.0, ransom_now_draw - ransom_collect_started)
            remaining = max(0, int(RANSOM_TIME_LIMIT - elapsed + 0.999))
            timer_text = f"{remaining // 60}:{remaining % 60:02d}"
            draw_text(screen, f"RANSOM POINTS: {ransom_coins_collected}/{RANSOM_GOAL}", CAM_X + 12, CAM_Y + 12, WHITE, TITLE)
            draw_text(screen, timer_text, CAM_X + CAM_W - 95, CAM_Y + 12, WHITE, TITLE)
            for cx, cy, radius, coin_id in ransom_coin_positions:
                sx, sy = CAM_X + cx, CAM_Y + cy
                coin_image = RANSOM_IMAGES.get("coin")
                if coin_image is not None:
                    coin_size = 34
                    if coin_image.get_size() != (coin_size, coin_size):
                        coin_image = pygame.transform.smoothscale(coin_image, (coin_size, coin_size))
                    screen.blit(coin_image, (sx - coin_size // 2, sy - coin_size // 2))
                else:
                    # Fallback if coin.png hasn't been added yet.
                    pygame.draw.circle(screen, (255, 210, 40), (sx, sy), radius + 3, 2)
                    pygame.draw.circle(screen, (255, 235, 100), (sx, sy), radius)
                draw_text(screen, " ", sx - 12, sy + 15, WHITE, SMALL)
            draw_text(screen, "CLICK COINS (+5 POINTS EACH)", CAM_X + 12, CAM_Y + CAM_H - 28, WHITE, SMALL)
        elif ransom_phase == "success":
            draw_text(screen, "RANSOM COMPLETE - 500 POINTS", CAM_X + 220, CAM_Y + CAM_H - 30, WHITE, SMALL)

    # Added minigame HUD overlays. These are screen overlays, not camera effects.
    if active_minigame == "radar":
        panel = pygame.Rect(CAM_X + CAM_W - 170, CAM_Y + 8, 158, 128)
        pygame.draw.rect(screen, (4, 20, 15), panel)
        pygame.draw.rect(screen, GREEN, panel, 2)
        radar_center = (CAM_X + CAM_W - 91, CAM_Y + 82)
        pygame.draw.circle(screen, GREEN, radar_center, 40, 1)
        pygame.draw.circle(screen, GREEN, radar_center, 20, 1)
        pygame.draw.line(screen, GREEN, (radar_center[0] - 40, radar_center[1]), (radar_center[0] + 40, radar_center[1]), 1)
        pygame.draw.line(screen, GREEN, (radar_center[0], radar_center[1] - 40), (radar_center[0], radar_center[1] + 40), 1)
        pulse = 5 + int((time.time() * 5) % 5)
        pygame.draw.circle(screen, YELLOW, (CAM_X + minigame_target[0], CAM_Y + minigame_target[1]), pulse, 2)
        draw_text(screen, f"RADAR TARGET: {max(0, int(minigame_deadline - time.time()))}s", panel.x + 5, panel.y + 4, GREEN, SMALL)
    elif active_minigame == "thermal":
        tx, ty = CAM_X + minigame_target[0], CAM_Y + minigame_target[1]
        pulse = 9 + int((time.time() * 7) % 6)
        pygame.draw.circle(screen, (255, 110, 30), (tx, ty), pulse, 2)
        pygame.draw.line(screen, (255, 180, 45), (tx - 16, ty), (tx + 16, ty), 2)
        pygame.draw.line(screen, (255, 180, 45), (tx, ty - 16), (tx, ty + 16), 2)
        draw_text(screen, f"THERMAL: CLICK HOTSPOT  {max(0, int(minigame_deadline - time.time()))}s", CAM_X + 12, CAM_Y + CAM_H - 28, (255, 150, 45), SMALL)
    elif active_minigame == "signal":
        panel = pygame.Rect(CAM_X + 160, CAM_Y + 95, 480, 150)
        pygame.draw.rect(screen, (5, 15, 24), panel)
        pygame.draw.rect(screen, CYAN, panel, 2)
        draw_text(screen, "SIGNAL TUNER - ARROWS TO ADJUST, ENTER TO LOCK", panel.x + 12, panel.y + 10, CYAN, SMALL)
        track = pygame.Rect(panel.x + 20, panel.y + 62, 440, 18)
        pygame.draw.rect(screen, (35, 55, 65), track)
        pygame.draw.rect(screen, CYAN, track, 1)
        target_x = track.x + int((minigame_signal_target / 100) * track.width)
        value_x = track.x + int((minigame_signal_value / 100) * track.width)
        pygame.draw.line(screen, YELLOW, (target_x, track.y - 10), (target_x, track.bottom + 10), 3)
        pygame.draw.circle(screen, WHITE, (value_x, track.centery), 8)
        draw_text(screen, f"FREQUENCY {minigame_signal_value:03d}    TIME {max(0, int(minigame_deadline - time.time()))}s", panel.x + 20, panel.y + 100, WHITE, SMALL)
    elif active_minigame == "anomaly":
        draw_text(screen, f"ANOMALY HUNT: CLICK A MAGENTA BOX  {max(0, int(minigame_deadline - time.time()))}s", CAM_X + 12, CAM_Y + CAM_H - 28, (255, 80, 220), SMALL)
        if not motion_boxes:
            draw_text(screen, "WAIT FOR MOVEMENT TO APPEAR", CAM_X + 250, CAM_Y + CAM_H // 2, (255, 80, 220), SMALL)

    if time.time() < minigame_message_until and minigame_message:
        msg_rect = pygame.Rect(CAM_X + 180, CAM_Y + CAM_H - 55, 440, 32)
        pygame.draw.rect(screen, (5, 15, 20), msg_rect)
        pygame.draw.rect(screen, CYAN if "SUCCESS" in minigame_message or "LOCKED" in minigame_message or "FOUND" in minigame_message or "CONFIRMED" in minigame_message or "ACTIVE" in minigame_message else RED, msg_rect, 2)
        draw_text(screen, minigame_message, msg_rect.x + 10, msg_rect.y + 7, WHITE, SMALL)

    if modules.get("Power Module", False):
        power_now_draw = time.time()
        if power_now_draw < power_shield_until:
            power_text = f"POWER SHIELD: ACTIVE {int(power_shield_until - power_now_draw + 0.999)}s"
            power_color = GREEN
        elif power_now_draw < power_shield_cooldown_until:
            power_text = f"POWER SHIELD: COOLDOWN {int(power_shield_cooldown_until - power_now_draw + 0.999)}s"
            power_color = YELLOW
        else:
            power_text = "POWER SHIELD: READY (P)"
            power_color = CYAN
        draw_text(screen, power_text, 8, 430, power_color, SMALL)

    # Battery indicator in the left-side margin.
    draw_text(screen, "BATTERY", 14, 176, GREEN if battery_level > 20 else RED, SMALL)
    battery_x, battery_y, battery_w, battery_h = 32, 205, 28, 150
    pygame.draw.rect(screen, (45, 60, 55), (battery_x, battery_y, battery_w, battery_h), border_radius=4)
    pygame.draw.rect(screen, (110, 130, 120), (battery_x, battery_y, battery_w, battery_h), 2, border_radius=4)
    inner_margin = 4
    inner_h = battery_h - inner_margin * 2
    fill_h = int(inner_h * (battery_level / 100.0))
    if battery_level > 50:
        battery_color = GREEN
    elif battery_level > 20:
        battery_color = YELLOW
    else:
        battery_color = RED
    if fill_h > 0:
        pygame.draw.rect(screen, battery_color, (battery_x + inner_margin, battery_y + battery_h - inner_margin - fill_h, battery_w - inner_margin * 2, fill_h), border_radius=2)
    pygame.draw.rect(screen, (110, 130, 120), (battery_x + 7, battery_y - 5, battery_w - 14, 5), border_radius=2)
    draw_text(screen, f"{int(battery_level):3d}%", 14, 365, battery_color, SMALL)
    draw_text(screen, "CHARGING" if not powered and battery_level < 100 else ("IN USE" if powered else "READY"), 12, 386, battery_color, SMALL)
    if powered:
        draw_text(screen, f"DRAIN {battery_drain_rate:.2f}%/s", 8, 407, battery_color, SMALL)
    else:
        draw_text(screen, "DRAIN 0.00%/s", 8, 407, battery_color, SMALL)

    # Frame border and footer status
    pygame.draw.rect(screen, CYAN if powered else (75, 85, 95), (CAM_X - 2, CAM_Y - 2, CAM_W + 4, CAM_H + 4), 2)
    if not modules.get("Minimal HUD", False):
        enabled = [name for name, state in modules.items() if state]
        module_text = ", ".join(enabled) if enabled else "None"
        draw_text(screen, f"ACTIVE MODULES: {module_text[:100]}", 100, 480, CYAN, SMALL)
        draw_text(screen, f"ZOOM: {zoom_level:.1f}x  (+/- to adjust, 0 reset)", 100, 503, WHITE, SMALL)
        ambience_status = "LOW AMBIENCE: 15% / BATTERY DRAIN x5" if ambience_silent_mode else "AMBIENCE: NORMAL"
        draw_text(screen, ambience_status, 600, 503, YELLOW if ambience_silent_mode else WHITE, SMALL)
        draw_text(screen, "Thermal Vision is a visual filter; no real temperature is measured.", 100, 526, YELLOW, SMALL)
        if modules.get("Snapshot / Freeze Frame", False):
            draw_text(screen, "SPACE: FREEZE/RESUME   S: SAVE SNAPSHOT", 100, 548, GREEN, SMALL)
        if modules.get("Pixel Inspector", False) or modules.get("Pixel Counter", False) or modules.get("Object Ruler", False):
            draw_text(screen, "MOUSE: INSPECT / SAMPLE COLOR / RULER POINTS   C: CLEAR RULER", 100, 548, GREEN, SMALL)
        if modules.get("Space Module", False):
            draw_text(screen, "SPACE MODULE:  R = MOVEMENT + LIDAR SCAN   Q = NIGHT VISION + DISTANCE", 100, 592, GREEN, SMALL)
        challenge_keys = []
        if modules.get("Radar Scanner", False): challenge_keys.append("G: RADAR GAME")
        if modules.get("Thermal Vision", False): challenge_keys.append("H: THERMAL GAME")
        if modules.get("Signal Scanner", False): challenge_keys.append("Y: SIGNAL GAME")
        if modules.get("Anomaly Module", False): challenge_keys.append("A: ANOMALY HUNT")
        if challenge_keys:
            draw_text(screen, "   ".join(challenge_keys), 100, 570, CYAN, SMALL)
        if modules.get("System Diagnostics", False):
            fps_now = clock.get_fps()
            draw_text(screen, f"DIAG FPS:{fps_now:04.1f}  PROC:{frame_process_ms:05.1f}ms  CAM:{CAM_W}x{CAM_H}", 100, 570, CYAN, SMALL)
        if modules.get("Power Saver", False):
            draw_text(screen, "POWER SAVER ACTIVE", 720, 548, GREEN, SMALL)
    else:
        draw_text(screen, f"ZOOM {zoom_level:.1f}x", 110, 480, GREEN, SMALL)
        if modules.get("System Diagnostics", False):
            draw_text(screen, f"{clock.get_fps():.0f} FPS", 110, 502, GREEN, SMALL)

    if time.time() < alert_until and alert_text:
        alert_rect = pygame.Rect(180, 440, 640, 34)
        pygame.draw.rect(screen, (75, 0, 0), alert_rect)
        pygame.draw.rect(screen, RED, alert_rect, 2)
        draw_text(screen, f"ALERT: {alert_text[:78]}", 192, 447, RED, SMALL)

    # Scrollable module menu with live information for the selected module.
    if menu_open:
        screen.blit(menu_overlay, (0, 0))
        draw_text(screen, "SCANNER MODULES & INFORMATION", 250, 88, CYAN, TITLE)
        pygame.draw.rect(screen, (8, 16, 22), module_list_area, border_radius=6)
        pygame.draw.rect(screen, (70, 110, 125), module_list_area, 2, border_radius=6)
        pygame.draw.rect(screen, (8, 16, 22), module_info_area, border_radius=6)
        pygame.draw.rect(screen, CYAN, module_info_area, 2, border_radius=6)
        # Clip module rows so scrolling never draws outside the list panel.
        previous_clip = screen.get_clip()
        screen.set_clip(module_list_area)
        for name, rect in menu_buttons():
            active = modules[name]
            selected = name == selected_module
            fill = (20, 70, 45) if active else ((28, 45, 58) if selected else (18, 27, 35))
            border = GREEN if active else (CYAN if selected else (75, 95, 108))
            pygame.draw.rect(screen, fill, rect, border_radius=4)
            pygame.draw.rect(screen, border, rect, 1 if not selected else 2, border_radius=4)
            label = f"{'[ON] ' if active else '[OFF] '}{name}"
            text_surf = SMALL.render(label, True, GREEN if active else WHITE)
            screen.blit(text_surf, (rect.x + 8, rect.y + 5))
        screen.set_clip(previous_clip)
        draw_text(screen, "MODULE INFORMATION", module_info_area.x + 18, module_info_area.y + 16, CYAN, FONT)
        info_name = selected_module if selected_module in MODULE_INFO else "Nightvision"
        info_description, info_energy = MODULE_INFO.get(info_name, ("No information available.", "Unknown"))
        draw_text(screen, info_name, module_info_area.x + 18, module_info_area.y + 54, GREEN, FONT)
        status_text = "STATUS: ENABLED" if modules.get(info_name, False) else "STATUS: DISABLED"
        draw_text(screen, status_text, module_info_area.x + 18, module_info_area.y + 84, GREEN if modules.get(info_name, False) else YELLOW, SMALL)
        draw_text(screen, f"ENERGY: {info_energy}", module_info_area.x + 18, module_info_area.y + 110, YELLOW, SMALL)
        # Word-wrap module descriptions into readable lines.
        words = info_description.split()
        lines = []
        line = ""
        for word in words:
            test_line = (line + " " + word).strip()
            if SMALL.size(test_line)[0] > module_info_area.width - 36:
                if line:
                    lines.append(line)
                line = word
            else:
                line = test_line
        if line:
            lines.append(line)
        for line_index, line_text in enumerate(lines[:6]):
            draw_text(screen, line_text, module_info_area.x + 18, module_info_area.y + 145 + line_index * 21, WHITE, SMALL)
        draw_text(screen, "RECENT SESSION EVENTS", module_info_area.x + 18, module_info_area.y + 285, CYAN, SMALL)
        for event_index, (event_time, event_name, details) in enumerate(recent_timeline_events[-3:]):
            event_line = f"{event_time} {event_name}: {details}"[:53]
            draw_text(screen, event_line, module_info_area.x + 18, module_info_area.y + 310 + event_index * 17, WHITE, SMALL)
        draw_text(screen, f"Scroll over list to browse {len(modules)} modules. Click a row to toggle/select.", 90, 525, WHITE, SMALL)
        draw_text(screen, "E / ESC closes menu. Radar/Thermal/Signal/Anomaly have minigames; range estimates are approximate.", 90, 550, YELLOW, SMALL)

    pygame.display.flip()

if camera is not None:
    camera.release()
pygame.quit()