plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nvcs3000.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nvcs3000.mobile"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-mobile-preview"
    }

    androidResources {
        noCompress += listOf("mp3")
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.camera:camera-camera2:1.4.2")
    implementation("androidx.camera:camera-lifecycle:1.4.2")
    implementation("androidx.camera:camera-view:1.4.2")
}
