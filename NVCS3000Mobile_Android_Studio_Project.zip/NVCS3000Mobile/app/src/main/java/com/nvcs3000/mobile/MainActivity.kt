package com.nvcs3000.mobile

import android.Manifest
import android.animation.ValueAnimator
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.media.MediaPlayer
import android.media.AudioAttributes
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var staticView: StaticView
    private lateinit var statusText: TextView
    private lateinit var batteryText: TextView
    private lateinit var powerButton: Button
    private lateinit var ambienceButton: Button
    private lateinit var cameraExecutor: ExecutorService
    private val handler = Handler(Looper.getMainLooper())
    private var cameraProvider: ProcessCameraProvider? = null
    private var scannerOn = false
    private var lowAmbience = false
    private var battery = 100.0
    private var lastPowerToggle = 0L
    private var currentAudioVolume = 0f
    private var ambiencePlayer: MediaPlayer? = null
    private var staticPlayer: MediaPlayer? = null
    private var volumeAnimator: ValueAnimator? = null
    private var batteryLoopRunning = false

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else statusText.text = "CAMERA PERMISSION REQUIRED"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildInterface()
        prepareAudio()
        statusText.text = "CAMERA PREPARING — SCANNER STANDBY"
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
        startBatteryLoop()
    }

    private fun buildInterface() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(1, 8, 4)) }
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        staticView = StaticView(this).apply { visibility = View.VISIBLE; alpha = 1f }
        root.addView(staticView, FrameLayout.LayoutParams(-1, -1))

        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(12))
            setBackgroundColor(Color.TRANSPARENT)
        }
        val title = TextView(this).apply {
            text = "N V C S   3 0 0 0"
            textSize = 22f
            setTextColor(Color.rgb(85, 255, 136))
            gravity = Gravity.CENTER
        }
        statusText = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(85, 255, 136))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        batteryText = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(8))
        }
        val spacer = View(this)
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        powerButton = Button(this).apply {
            text = "POWER ON"
            setOnClickListener { togglePower() }
        }
        ambienceButton = Button(this).apply {
            text = "LOW AMBIENCE: OFF"
            setOnClickListener { toggleAmbience() }
        }
        buttons.addView(powerButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(5) })
        buttons.addView(ambienceButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(5) })
        overlay.addView(title)
        overlay.addView(statusText)
        overlay.addView(batteryText)
        overlay.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        overlay.addView(buttons)
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun startCamera() {
        statusText.text = "CONNECTING TO CAMERA..."
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                cameraProvider = provider
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview)
                statusText.text = "CAMERA READY — SCANNER STANDBY"
            } catch (e: Exception) {
                statusText.text = "CAMERA ERROR: ${e.javaClass.simpleName}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun togglePower() {
        val now = System.currentTimeMillis()
        if (now - lastPowerToggle < 800L) return // silent 0.8 second cooldown
        lastPowerToggle = now
        scannerOn = !scannerOn
        powerButton.text = if (scannerOn) "POWER OFF" else "POWER ON"
        if (scannerOn) {
            statusText.text = "INITIALIZING SCANNER..."
            staticView.visibility = View.VISIBLE
            staticView.alpha = 1f
            staticView.startNoise()
            setAudioVolume(if (lowAmbience) 0.15f else 1f)
            staticPlayer?.let { if (!it.isPlaying) { try { it.start() } catch (_: Exception) {} } }
            handler.postDelayed({
                if (scannerOn) {
                    val fade = ValueAnimator.ofFloat(1f, 0f).setDuration(1000L)
                    fade.addUpdateListener { staticView.alpha = it.animatedValue as Float }
                    fade.addListener(object : android.animation.AnimatorListenerAdapter() {
                        override fun onAnimationEnd(animation: android.animation.Animator) {
                            if (scannerOn) {
                                staticView.visibility = View.GONE
                                staticView.stopNoise()
                                statusText.text = "SCANNER ONLINE"
                            }
                        }
                    })
                    fade.start()
                }
            }, 250L)
            ambiencePlayer?.let { if (!it.isPlaying) { try { it.start() } catch (_: Exception) {} } }
        } else {
            statusText.text = "SCANNER STANDBY"
            staticView.visibility = View.VISIBLE
            staticView.alpha = 1f
            staticView.stopNoise()
            setAudioVolume(0f)
        }
    }

    private fun toggleAmbience() {
        lowAmbience = !lowAmbience
        ambienceButton.text = if (lowAmbience) "LOW AMBIENCE: ON" else "LOW AMBIENCE: OFF"
        setAudioVolume(if (scannerOn) if (lowAmbience) 0.15f else 1f else 0f)
        statusText.text = if (lowAmbience) "LOW AMBIENCE — 15% / 5X DRAIN" else if (scannerOn) "SCANNER ONLINE" else "SCANNER STANDBY"
    }

    private fun prepareAudio() {
        ambiencePlayer = makePlayer("nvcs/audio/Scanner_Ambience.mp3", true)
        staticPlayer = makePlayer("nvcs/audio/Scanner_static.mp3.mp3", true)
        ambiencePlayer?.setVolume(0f, 0f)
        staticPlayer?.setVolume(0f, 0f)
    }

    private fun makePlayer(path: String, looping: Boolean): MediaPlayer? {
        return try {
            val afd = assets.openFd(path)
            MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                isLooping = looping
                prepare()
            }
        } catch (_: Exception) { null }
    }

    private fun setAudioVolume(target: Float) {
        volumeAnimator?.cancel()
        volumeAnimator = ValueAnimator.ofFloat(currentAudioVolume, target.coerceIn(0f, 1f)).setDuration(450L).apply {
            addUpdateListener { anim ->
                val v = (anim.animatedValue as Float).coerceIn(0f, 1f)
                currentAudioVolume = v
                ambiencePlayer?.setVolume(v, v)
                staticPlayer?.setVolume(v, v)
            }
            start()
        }
    }

    private fun startBatteryLoop() {
        if (batteryLoopRunning) return
        batteryLoopRunning = true
        handler.post(object : Runnable {
            override fun run() {
                if (scannerOn && battery > 0) {
                    battery -= (if (lowAmbience) 0.35 else 0.07) // simulated drain, 5x low-ambience multiplier
                    if (battery <= 0) { battery = 0.0; scannerOn = false; powerButton.text = "POWER ON"; statusText.text = "BATTERY EMPTY — SCANNER OFF"; staticView.visibility = View.VISIBLE; setAudioVolume(0f) }
                }
                batteryText.text = "SIMULATED BATTERY: ${battery.toInt()}%${if (lowAmbience) "  |  DRAIN x5" else ""}"
                handler.postDelayed(this, 1000L)
            }
        })
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        cameraProvider?.unbindAll()
        cameraExecutor.shutdown()
        volumeAnimator?.cancel()
        ambiencePlayer?.release()
        staticPlayer?.release()
        super.onDestroy()
    }

    private class StaticView(context: android.content.Context) : View(context) {
        private val paint = Paint()
        private var noiseOn = false
        private val refresh = Handler(Looper.getMainLooper())
        private val loop = object : Runnable { override fun run() { invalidate(); if (noiseOn) refresh.postDelayed(this, 70L) } }
        fun startNoise() { noiseOn = true; refresh.removeCallbacks(loop); refresh.post(loop) }
        fun stopNoise() { noiseOn = false; refresh.removeCallbacks(loop) }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.rgb(0, 18, 6))
            val step = max(5, width / 75)
            for (y in 0 until height step step) {
                for (x in 0 until width step step) {
                    val a = Random.nextInt(20, if (noiseOn) 180 else 70)
                    paint.color = Color.argb(a, 60, 255, Random.nextInt(70, 160))
                    canvas.drawRect(x.toFloat(), y.toFloat(), (x + step).toFloat(), (y + step).toFloat(), paint)
                }
            }
            paint.color = Color.argb(170, 85, 255, 136)
            paint.textSize = max(22f, width / 22f)
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("NVCS 3000", width / 2f, height / 2f, paint)
            paint.textSize = max(12f, width / 48f)
            canvas.drawText(if (noiseOn) "INITIALIZING SIGNAL..." else "SCANNER STANDBY", width / 2f, height / 2f + paint.textSize * 1.8f, paint)
        }
    }
}
